export interface User {
  id: string
  name: string
  email: string
  bio: string
  profilePicture?: string
  skillsToTeach: string[]
  skillsToLearn: string[]
  location: string
  rating: number
  totalExchanges: number
  joinedDate: string
  points: number
  skillsTaught: number
  skillsLearned: number
  isOnline: boolean
  learningMode: "online" | "physical" | "both"
  availableForPhysical: boolean
  physicalLocation?: string
}

export interface Message {
  id: string
  senderId: string
  receiverId: string
  content: string
  timestamp: string
  read: boolean
}

export interface Conversation {
  id: string
  participants: string[]
  lastMessage: Message
  unreadCount: number
}

export interface UserStats {
  points: number
  skillsTaught: number
  skillsLearned: number
  newMessages: number
}
