import type { User } from "./types"

export const sampleUsers: User[] = [
  {
    id: "user-1",
    name: "Sarah Chen",
    email: "sarah.chen@email.com",
    bio: "Full-stack developer with 5 years of experience. Love teaching web development and learning new design skills!",
    profilePicture: "/professional-woman.png",
    skillsToTeach: ["React", "Node.js", "TypeScript", "Web Development"],
    skillsToLearn: ["UI/UX Design", "Figma", "Photography"],
    location: "San Francisco, CA",
    rating: 4.9,
    totalExchanges: 23,
    joinedDate: "2024-01-15",
    points: 2000, // 4 skills * 500 points
    skillsTaught: 15,
    skillsLearned: 8,
    isOnline: true,
    learningMode: "both",
    availableForPhysical: true,
    physicalLocation: "San Francisco Bay Area",
  },
  {
    id: "user-2",
    name: "Marcus Johnson",
    email: "marcus.j@email.com",
    bio: "Professional photographer and graphic designer. Always excited to share creative techniques and learn technical skills.",
    profilePicture: "/professional-man.png",
    skillsToTeach: ["Photography", "Photoshop", "Graphic Design", "Lightroom"],
    skillsToLearn: ["Web Development", "Python", "Data Analysis"],
    location: "New York, NY",
    rating: 4.8,
    totalExchanges: 31,
    joinedDate: "2023-11-20",
    points: 2000, // 4 skills * 500 points
    skillsTaught: 22,
    skillsLearned: 9,
    isOnline: false,
    learningMode: "physical",
    availableForPhysical: true,
    physicalLocation: "Manhattan, NYC",
  },
  {
    id: "user-3",
    name: "Elena Rodriguez",
    email: "elena.r@email.com",
    bio: "Marketing professional with expertise in digital strategy. Looking to expand into technical skills while sharing marketing knowledge.",
    profilePicture: "/woman-designer.png",
    skillsToTeach: ["Digital Marketing", "Content Strategy", "Social Media", "SEO"],
    skillsToLearn: ["JavaScript", "Data Visualization", "SQL"],
    location: "Austin, TX",
    rating: 4.7,
    totalExchanges: 18,
    joinedDate: "2024-02-10",
    points: 2000, // 4 skills * 500 points
    skillsTaught: 12,
    skillsLearned: 6,
    isOnline: true,
    learningMode: "online",
    availableForPhysical: false,
  },
  {
    id: "user-4",
    name: "David Kim",
    email: "david.kim@email.com",
    bio: "Data scientist and machine learning engineer. Passionate about teaching analytics and learning creative skills.",
    profilePicture: "/professional-headshot.png",
    skillsToTeach: ["Python", "Data Science", "Machine Learning", "SQL"],
    skillsToLearn: ["Guitar", "Video Editing", "Public Speaking"],
    location: "Seattle, WA",
    rating: 4.9,
    totalExchanges: 27,
    joinedDate: "2023-12-05",
    points: 2000, // 4 skills * 500 points
    skillsTaught: 18,
    skillsLearned: 9,
    isOnline: true,
    learningMode: "both",
    availableForPhysical: true,
    physicalLocation: "Seattle Metro Area",
  },
  {
    id: "user-5",
    name: "Priya Patel",
    email: "priya.patel@email.com",
    bio: "UX designer with a background in psychology. Love helping others understand user-centered design principles.",
    profilePicture: "/professional-woman.png",
    skillsToTeach: ["UI/UX Design", "Figma", "User Research", "Wireframing"],
    skillsToLearn: ["React", "Frontend Development", "Animation"],
    location: "Los Angeles, CA",
    rating: 4.8,
    totalExchanges: 22,
    joinedDate: "2024-01-30",
    points: 2000, // 4 skills * 500 points
    skillsTaught: 14,
    skillsLearned: 8,
    isOnline: false,
    learningMode: "physical",
    availableForPhysical: true,
    physicalLocation: "Greater LA Area",
  },
  {
    id: "user-6",
    name: "Alex Thompson",
    email: "alex.t@email.com",
    bio: "Music producer and audio engineer. Always looking to learn new technical skills while sharing music production knowledge.",
    profilePicture: "/professional-man.png",
    skillsToTeach: ["Music Production", "Audio Engineering", "Logic Pro", "Sound Design"],
    skillsToLearn: ["Web Development", "Mobile App Development", "3D Modeling"],
    location: "Nashville, TN",
    rating: 4.6,
    totalExchanges: 15,
    joinedDate: "2024-03-01",
    points: 2000, // 4 skills * 500 points
    skillsTaught: 10,
    skillsLearned: 5,
    isOnline: true,
    learningMode: "online",
    availableForPhysical: false,
  },
  {
    id: "user-7",
    name: "Amara Okafor",
    email: "amara.okafor@email.com",
    bio: "Cybersecurity specialist and ethical hacker. Passionate about teaching security best practices and learning business strategy.",
    profilePicture: "/professional-woman.png",
    skillsToTeach: ["Cybersecurity", "Ethical Hacking", "Network Security"],
    skillsToLearn: ["Business Strategy", "Leadership", "Public Speaking"],
    location: "Atlanta, GA",
    rating: 4.9,
    totalExchanges: 19,
    joinedDate: "2023-10-12",
    points: 1500, // 3 skills * 500 points
    skillsTaught: 16,
    skillsLearned: 7,
    isOnline: true,
    learningMode: "both",
    availableForPhysical: true,
    physicalLocation: "Atlanta Metro",
  },
  {
    id: "user-8",
    name: "Carlos Mendoza",
    email: "carlos.mendoza@email.com",
    bio: "Mechanical engineer and 3D printing enthusiast. Love sharing engineering knowledge and learning creative arts.",
    profilePicture: "/professional-man.png",
    skillsToTeach: ["3D Printing", "CAD Design", "Mechanical Engineering", "Arduino", "Robotics"],
    skillsToLearn: ["Digital Art", "Animation", "Video Production"],
    location: "Phoenix, AZ",
    rating: 4.7,
    totalExchanges: 24,
    joinedDate: "2023-09-18",
    points: 2500, // 5 skills * 500 points
    skillsTaught: 20,
    skillsLearned: 4,
    isOnline: false,
    learningMode: "physical",
    availableForPhysical: true,
    physicalLocation: "Phoenix Valley",
  },
  {
    id: "user-9",
    name: "Yuki Tanaka",
    email: "yuki.tanaka@email.com",
    bio: "Game developer and Unity expert. Excited to teach game development and learn mobile app development.",
    profilePicture: "/professional-woman.png",
    skillsToTeach: ["Unity", "Game Development", "C#"],
    skillsToLearn: ["Swift", "iOS Development", "Flutter"],
    location: "Portland, OR",
    rating: 4.8,
    totalExchanges: 17,
    joinedDate: "2024-01-08",
    points: 1500, // 3 skills * 500 points
    skillsTaught: 13,
    skillsLearned: 4,
    isOnline: true,
    learningMode: "online",
    availableForPhysical: false,
  },
  {
    id: "user-10",
    name: "Ahmed Hassan",
    email: "ahmed.hassan@email.com",
    bio: "DevOps engineer and cloud architect. Passionate about infrastructure and eager to learn frontend technologies.",
    profilePicture: "/professional-man.png",
    skillsToTeach: ["AWS", "Docker", "Kubernetes", "DevOps", "Linux", "Terraform"],
    skillsToLearn: ["React", "Vue.js", "UI Design"],
    location: "Denver, CO",
    rating: 4.9,
    totalExchanges: 32,
    joinedDate: "2023-08-25",
    points: 3000, // 6 skills * 500 points
    skillsTaught: 28,
    skillsLearned: 4,
    isOnline: true,
    learningMode: "both",
    availableForPhysical: true,
    physicalLocation: "Denver Metro Area",
  },
  {
    id: "user-11",
    name: "Isabella Santos",
    email: "isabella.santos@email.com",
    bio: "Digital marketing strategist and content creator. Love teaching social media strategy and learning technical skills.",
    profilePicture: "/professional-woman.png",
    skillsToTeach: ["Instagram Marketing", "TikTok Strategy", "Content Creation", "Influencer Marketing"],
    skillsToLearn: ["Python", "Data Analytics", "Web Scraping"],
    location: "Miami, FL",
    rating: 4.6,
    totalExchanges: 21,
    joinedDate: "2024-02-14",
    points: 2000, // 4 skills * 500 points
    skillsTaught: 18,
    skillsLearned: 3,
    isOnline: true,
    learningMode: "online",
    availableForPhysical: false,
  },
  {
    id: "user-12",
    name: "Robert Chen",
    email: "robert.chen@email.com",
    bio: "Financial analyst and Excel expert. Passionate about teaching financial modeling and learning programming.",
    profilePicture: "/professional-man.png",
    skillsToTeach: ["Excel", "Financial Modeling", "Power BI"],
    skillsToLearn: ["Python", "R", "Machine Learning"],
    location: "Chicago, IL",
    rating: 4.7,
    totalExchanges: 26,
    joinedDate: "2023-11-30",
    points: 1500, // 3 skills * 500 points
    skillsTaught: 22,
    skillsLearned: 4,
    isOnline: false,
    learningMode: "physical",
    availableForPhysical: true,
    physicalLocation: "Chicago Downtown",
  },
  {
    id: "user-13",
    name: "Fatima Al-Zahra",
    email: "fatima.alzahra@email.com",
    bio: "Blockchain developer and cryptocurrency expert. Teaching blockchain technology and learning traditional finance.",
    profilePicture: "/professional-woman.png",
    skillsToTeach: ["Blockchain", "Solidity", "Smart Contracts", "Cryptocurrency"],
    skillsToLearn: ["Traditional Finance", "Investment Banking", "Risk Management"],
    location: "Boston, MA",
    rating: 4.8,
    totalExchanges: 14,
    joinedDate: "2024-03-20",
    points: 2000, // 4 skills * 500 points
    skillsTaught: 11,
    skillsLearned: 3,
    isOnline: true,
    learningMode: "both",
    availableForPhysical: true,
    physicalLocation: "Greater Boston",
  },
  {
    id: "user-14",
    name: "James Wilson",
    email: "james.wilson@email.com",
    bio: "Professional chef and culinary instructor. Love teaching cooking techniques and learning digital skills.",
    profilePicture: "/professional-man.png",
    skillsToTeach: ["Cooking", "Baking", "Food Photography", "Recipe Development", "Kitchen Management"],
    skillsToLearn: ["Social Media Marketing", "Website Development", "E-commerce"],
    location: "New Orleans, LA",
    rating: 4.9,
    totalExchanges: 29,
    joinedDate: "2023-07-15",
    points: 2500, // 5 skills * 500 points
    skillsTaught: 25,
    skillsLearned: 4,
    isOnline: false,
    learningMode: "physical",
    availableForPhysical: true,
    physicalLocation: "New Orleans Metro",
  },
  {
    id: "user-15",
    name: "Lisa Park",
    email: "lisa.park@email.com",
    bio: "Product manager and startup advisor. Passionate about teaching product strategy and learning technical implementation.",
    profilePicture: "/professional-woman.png",
    skillsToTeach: ["Product Management", "Agile", "User Stories"],
    skillsToLearn: ["React", "API Development", "Database Design"],
    location: "San Diego, CA",
    rating: 4.7,
    totalExchanges: 20,
    joinedDate: "2024-01-22",
    points: 1500, // 3 skills * 500 points
    skillsTaught: 16,
    skillsLearned: 4,
    isOnline: true,
    learningMode: "online",
    availableForPhysical: false,
  },
]

// Get all users including current user
export const getAllUsers = (currentUserId?: string): User[] => {
  let allUsers = [...sampleUsers]

  // If there's a current user, get their data from localStorage and include it
  if (currentUserId) {
    const userData = localStorage.getItem("userData")
    const authData = localStorage.getItem("authData")

    if (userData && authData) {
      const parsedUserData = JSON.parse(userData)
      const parsedAuthData = JSON.parse(authData)

      const skillsToTeach = parsedUserData.skillsToTeach || []
      const calculatedPoints = skillsToTeach.length * 500

      // Create current user object
      const currentUser: User = {
        id: currentUserId,
        name: parsedAuthData.name,
        email: parsedAuthData.email,
        bio: parsedUserData.bio || "No bio available",
        profilePicture: parsedUserData.profilePicture || "/placeholder.svg",
        skillsToTeach: skillsToTeach,
        skillsToLearn: parsedUserData.skillsToLearn || [],
        location: parsedUserData.location || "Location not set",
        rating: 5.0,
        totalExchanges: 0,
        joinedDate: new Date().toISOString().split("T")[0],
        points: calculatedPoints,
        skillsTaught: parsedUserData.skillsTaught || 0,
        skillsLearned: parsedUserData.skillsLearned || 0,
        isOnline: true,
        learningMode: parsedUserData.learningMode || "online",
        availableForPhysical: parsedUserData.availableForPhysical || false,
        physicalLocation: parsedUserData.physicalLocation,
      }

      // Remove any existing user with the same ID and add the current user
      allUsers = allUsers.filter((user) => user.id !== currentUserId)
      allUsers.unshift(currentUser) // Add current user at the beginning
    }
  }

  return allUsers
}

// Get all users except current user
export const getOtherUsers = (currentUserId?: string): User[] => {
  return getAllUsers(currentUserId).filter((user) => user.id !== currentUserId)
}

// Get user by ID
export const getUserById = (id: string): User | undefined => {
  return getAllUsers().find((user) => user.id === id)
}

// Search users by skills or name
export const searchUsers = (query: string, currentUserId?: string): User[] => {
  const allUsers = getAllUsers(currentUserId)
  const lowercaseQuery = query.toLowerCase()

  return allUsers.filter(
    (user) =>
      user.name.toLowerCase().includes(lowercaseQuery) ||
      user.skillsToTeach.some((skill) => skill.toLowerCase().includes(lowercaseQuery)) ||
      user.skillsToLearn.some((skill) => skill.toLowerCase().includes(lowercaseQuery)) ||
      user.location.toLowerCase().includes(lowercaseQuery),
  )
}

// Get all users including current user for exchange page
export const getAllUsersForExchange = (currentUserId?: string): User[] => {
  return getAllUsers(currentUserId)
}
