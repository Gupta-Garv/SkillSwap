"use client"

import { useState, useEffect } from "react"
import type { Conversation, Message } from "@/lib/types"
import {
  getConversations,
  getConversationMessages,
  sendMessage as sendMessageToStorage,
  markMessagesAsRead,
  getUnreadMessageCount,
} from "@/lib/messaging"

export function useMessaging(currentUserId = "current-user") {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [unreadCount, setUnreadCount] = useState(0)

  // Load conversations and unread count
  const refreshConversations = () => {
    const convs = getConversations(currentUserId)
    setConversations(convs)
    setUnreadCount(getUnreadMessageCount(currentUserId))
  }

  // Load messages for selected conversation
  const loadMessages = (otherUserId: string) => {
    const conversationMessages = getConversationMessages(currentUserId, otherUserId)
    setMessages(conversationMessages)

    // Mark messages as read
    markMessagesAsRead(currentUserId, otherUserId)
    refreshConversations()
  }

  // Send a message
  const sendMessage = (receiverId: string, content: string) => {
    const newMessage = sendMessageToStorage(currentUserId, receiverId, content)

    // If this is the active conversation, update messages
    if (selectedConversation === receiverId) {
      setMessages((prev) => [...prev, newMessage])
    }

    refreshConversations()
    return newMessage
  }

  // Select a conversation
  const selectConversation = (otherUserId: string) => {
    setSelectedConversation(otherUserId)
    loadMessages(otherUserId)
  }

  // Initialize
  useEffect(() => {
    refreshConversations()
  }, [currentUserId])

  return {
    conversations,
    selectedConversation,
    messages,
    unreadCount,
    sendMessage,
    selectConversation,
    refreshConversations,
  }
}
