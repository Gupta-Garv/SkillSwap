"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Users, Zap, Target, Globe } from "lucide-react"
import Link from "next/link"
import { useUser } from "@/hooks/use-user"

const features = [
  {
    icon: Users,
    title: "Expert Network",
    description: "Connect with industry professionals and exchange knowledge through structured learning sessions.",
  },
  {
    icon: Zap,
    title: "Skill Matching",
    description: "Advanced algorithms pair you with the perfect learning partners based on complementary expertise.",
  },
  {
    icon: Target,
    title: "Goal Tracking",
    description: "Set learning objectives and track your progress with detailed analytics and milestone achievements.",
  },
  {
    icon: Globe,
    title: "Global Community",
    description: "Access a worldwide network of professionals across industries, time zones, and skill levels.",
  },
]

export default function LandingPage() {
  const [isVisible, setIsVisible] = useState(false)
  const { currentUser } = useUser()

  useEffect(() => {
    setIsVisible(true)

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate")
          }
        })
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" },
    )

    const elements = document.querySelectorAll(".fade-in-up, .fade-in-left, .fade-in-right, .scale-in")
    elements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <nav className="fixed top-0 w-full bg-gradient-to-r from-background/90 via-background/95 to-background/90 backdrop-blur-xl border-b border-border z-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link href={currentUser ? "/dashboard" : "/"}>
              <h1 className="text-3xl font-bold text-foreground hover:text-primary transition-all duration-300 float">
                SkillSwap
              </h1>
            </Link>
            <Link href="/auth">
              <Button className="gradient-button pulse-glow">Get Started</Button>
            </Link>
          </div>
        </div>
      </nav>

      <section className="min-h-screen flex items-center justify-center px-6 lg:px-8 pt-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/10"></div>
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <div
            className={`transition-all duration-1000 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <h1 className="text-7xl md:text-9xl font-bold text-foreground mb-8 leading-tight float">
              <span className="bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent">
                SkillSwap
              </span>
            </h1>
            <p className="text-2xl md:text-3xl text-muted-foreground mb-8 font-light max-w-4xl mx-auto leading-relaxed fade-in-up stagger-1">
              Transform your career through peer-to-peer learning and expert knowledge exchange
            </p>
            <div className="fade-in-up stagger-2">
              <Link href="/auth">
                <Button className="gradient-button text-xl px-12 py-6 rounded-xl pulse-glow hover:scale-105 transition-all duration-300">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-32 px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <div className="gradient-card fade-in-up p-12 text-center">
            <h2 className="text-5xl md:text-6xl font-bold text-foreground mb-8 scale-in stagger-1">Our Mission</h2>
            <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed fade-in-up stagger-2">
              We believe every professional has valuable knowledge to share and skills to learn. SkillSwap creates
              meaningful connections that accelerate career growth through collaborative learning experiences and expert
              knowledge exchange.
            </p>
          </div>
        </div>
      </section>

      <section className="py-32 px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20 fade-in-up">
            <h2 className="text-5xl md:text-6xl font-bold text-foreground mb-6 scale-in">Core Features</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto fade-in-up stagger-1">
              Discover the tools and connections that will transform your professional journey
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <div key={index} className={`gradient-card fade-in-up stagger-${index + 1} p-8 group cursor-pointer`}>
                <div className="flex items-start space-x-6">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center group-hover:from-primary/30 group-hover:to-primary/20 transition-all duration-300 pulse-glow">
                      <feature.icon className="w-8 h-8 text-primary" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-foreground mb-4 group-hover:text-primary transition-colors duration-300">
                      {feature.title}
                    </h3>
                    <p className="text-lg text-muted-foreground leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 px-6 lg:px-8 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5"></div>
        <div className="max-w-5xl mx-auto relative z-10">
          <div className="gradient-card fade-in-up p-12 text-center">
            <h2 className="text-5xl md:text-6xl font-bold text-foreground mb-8 scale-in">
              Ready to Accelerate Your Growth?
            </h2>
            <p className="text-xl md:text-2xl text-muted-foreground mb-12 leading-relaxed fade-in-up stagger-1">
              Join thousands of professionals already transforming their careers through expert connections and
              collaborative learning.
            </p>
            <div className="fade-in-up stagger-2">
              <Link href="/auth">
                <Button className="gradient-button text-2xl px-16 py-6 rounded-xl pulse-glow hover:scale-105 transition-all duration-300">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <footer className="py-16 px-6 lg:px-8 border-t border-border bg-gradient-to-r from-background via-secondary/20 to-background">
        <div className="max-w-7xl mx-auto text-center fade-in-up">
          <h3 className="text-2xl font-bold text-foreground mb-4 float">SkillSwap</h3>
          <p className="text-muted-foreground mb-6">Empowering professionals through knowledge exchange</p>
          <p className="text-muted-foreground/60 text-sm">© 2024 SkillSwap. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
