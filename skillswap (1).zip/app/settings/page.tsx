"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Settings, Monitor, Eye, Bell, Shield, Trash2, Save } from "lucide-react"
import { useUser } from "@/hooks/use-user"

const SettingsPage = () => {
  const { currentUser, updateUser } = useUser()
  const router = useRouter()
  const searchParams = useSearchParams()
  const [isVisible, setIsVisible] = useState(false)

  // Account Settings
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [marketingEmails, setMarketingEmails] = useState(false)

  // Learning Preferences
  const [learningMode, setLearningMode] = useState(currentUser?.learningMode || "both")
  const [availability, setAvailability] = useState("flexible")
  const [preferredSkillCategories, setPreferredSkillCategories] = useState(["Technology", "Design", "Business"])
  const [sessionDuration, setSessionDuration] = useState("60")

  // Privacy Settings
  const [profileVisibility, setProfileVisibility] = useState("public")
  const [showOnlineStatus, setShowOnlineStatus] = useState(true)
  const [allowMessages, setAllowMessages] = useState("everyone")
  const [showSkillsPublicly, setShowSkillsPublicly] = useState(true)
  const [dataSharing, setDataSharing] = useState(false)

  useEffect(() => {
    setIsVisible(true)

    // Scroll to section if hash is present
    const section = searchParams.get("section")
    if (section) {
      setTimeout(() => {
        const element = document.getElementById(section)
        if (element) {
          element.scrollIntoView({ behavior: "smooth" })
        }
      }, 100)
    }
  }, [searchParams])

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="gradient-card p-8 text-center max-w-md scale-in">
          <h2 className="text-2xl font-bold text-foreground mb-4">Please sign in to access settings</h2>
          <Link href="/auth">
            <Button className="gradient-button pulse-glow">Sign In</Button>
          </Link>
        </div>
      </div>
    )
  }

  const saveAccountSettings = () => {
    // In a real app, this would make API calls
    console.log("Saving account settings...")
    // Show success message
  }

  const saveLearningPreferences = () => {
    updateUser({
      ...currentUser,
      learningMode: learningMode,
    })
    console.log("Saving learning preferences...")
  }

  const savePrivacySettings = () => {
    console.log("Saving privacy settings...")
    // Show success message
  }

  const deleteAccount = () => {
    if (confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      localStorage.removeItem("authData")
      localStorage.removeItem("userData")
      router.push("/")
    }
  }

  const skillCategories = [
    "Technology",
    "Design",
    "Business",
    "Marketing",
    "Photography",
    "Writing",
    "Music",
    "Languages",
    "Cooking",
    "Fitness",
    "Art",
    "Science",
  ]

  const toggleSkillCategory = (category: string) => {
    setPreferredSkillCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/10"></div>

      <div className="max-w-4xl mx-auto px-6 lg:px-8 py-8 relative z-10">
        {/* Header */}
        <div
          className={`flex items-center justify-between mb-12 transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0 float animate" : "opacity-0 translate-y-8 float"
          }`}
        >
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.back()}
              className="text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Settings</h1>
              <p className="text-muted-foreground">Manage your account and preferences</p>
            </div>
          </div>
          <Link href="/dashboard" className="text-2xl font-bold text-foreground hover:text-primary transition-colors">
            SkillSwap
          </Link>
        </div>

        <div className="space-y-12">
          {/* Account Settings */}
          <section id="account" className={`${isVisible ? "fade-in-up stagger-1 animate" : "fade-in-up stagger-1"}`}>
            <Card className="gradient-card">
              <CardHeader className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg flex items-center justify-center">
                    <Settings className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-foreground text-2xl">Account Settings</CardTitle>
                    <p className="text-muted-foreground">Manage your account security and notifications</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6 px-6 pb-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="current-password" className="text-foreground mb-2 block">
                        Current Password
                      </Label>
                      <Input
                        id="current-password"
                        type="password"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="Enter current password"
                        className="bg-input border-border text-foreground"
                      />
                    </div>
                    <div>
                      <Label htmlFor="new-password" className="text-foreground mb-2 block">
                        New Password
                      </Label>
                      <Input
                        id="new-password"
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Enter new password"
                        className="bg-input border-border text-foreground"
                      />
                    </div>
                    <div>
                      <Label htmlFor="confirm-password" className="text-foreground mb-2 block">
                        Confirm New Password
                      </Label>
                      <Input
                        id="confirm-password"
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Confirm new password"
                        className="bg-input border-border text-foreground"
                      />
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <h4 className="text-foreground font-semibold mb-4 flex items-center gap-2">
                        <Bell className="h-4 w-4" />
                        Notification Preferences
                      </h4>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <Label className="text-foreground">Email Notifications</Label>
                            <p className="text-sm text-muted-foreground">
                              Receive notifications about messages and updates
                            </p>
                          </div>
                          <Switch checked={emailNotifications} onCheckedChange={setEmailNotifications} />
                        </div>
                        <div className="flex items-center justify-between">
                          <div>
                            <Label className="text-foreground">Marketing Emails</Label>
                            <p className="text-sm text-muted-foreground">Receive updates about new features and tips</p>
                          </div>
                          <Switch checked={marketingEmails} onCheckedChange={setMarketingEmails} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator className="bg-border" />

                <div className="flex justify-between items-center">
                  <Button onClick={saveAccountSettings} className="gradient-button">
                    <Save className="h-4 w-4 mr-2" />
                    Save Account Settings
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={deleteAccount}
                    className="bg-destructive hover:bg-destructive/90"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete Account
                  </Button>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Learning Preferences */}
          <section id="learning" className={`${isVisible ? "fade-in-up stagger-2 animate" : "fade-in-up stagger-2"}`}>
            <Card className="gradient-card">
              <CardHeader className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg flex items-center justify-center">
                    <Monitor className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-foreground text-2xl">Learning Preferences</CardTitle>
                    <p className="text-muted-foreground">Customize your learning experience and availability</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6 px-6 pb-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="learning-mode" className="text-foreground mb-2 block">
                        Learning Mode
                      </Label>
                      <Select value={learningMode} onValueChange={setLearningMode}>
                        <SelectTrigger className="bg-input border-border text-foreground">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="gradient-card border-border">
                          <SelectItem value="online">Online Only</SelectItem>
                          <SelectItem value="physical">Physical Only</SelectItem>
                          <SelectItem value="both">Both Online & Physical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="availability" className="text-foreground mb-2 block">
                        Availability
                      </Label>
                      <Select value={availability} onValueChange={setAvailability}>
                        <SelectTrigger className="bg-input border-border text-foreground">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="gradient-card border-border">
                          <SelectItem value="flexible">Flexible</SelectItem>
                          <SelectItem value="weekdays">Weekdays Only</SelectItem>
                          <SelectItem value="weekends">Weekends Only</SelectItem>
                          <SelectItem value="evenings">Evenings Only</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="session-duration" className="text-foreground mb-2 block">
                        Preferred Session Duration (minutes)
                      </Label>
                      <Select value={sessionDuration} onValueChange={setSessionDuration}>
                        <SelectTrigger className="bg-input border-border text-foreground">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="gradient-card border-border">
                          <SelectItem value="30">30 minutes</SelectItem>
                          <SelectItem value="60">1 hour</SelectItem>
                          <SelectItem value="90">1.5 hours</SelectItem>
                          <SelectItem value="120">2 hours</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label className="text-foreground mb-3 block">Preferred Skill Categories</Label>
                    <div className="flex flex-wrap gap-2">
                      {skillCategories.map((category) => (
                        <Badge
                          key={category}
                          variant={preferredSkillCategories.includes(category) ? "default" : "outline"}
                          className={`cursor-pointer transition-all duration-300 ${
                            preferredSkillCategories.includes(category)
                              ? "bg-gradient-to-r from-primary/20 to-primary/10 text-primary hover:from-primary/30 hover:to-primary/20"
                              : "border-border text-foreground hover:bg-secondary"
                          }`}
                          onClick={() => toggleSkillCategory(category)}
                        >
                          {category}
                        </Badge>
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      Select categories you're interested in to get better recommendations
                    </p>
                  </div>
                </div>

                <Separator className="bg-border" />

                <Button onClick={saveLearningPreferences} className="gradient-button">
                  <Save className="h-4 w-4 mr-2" />
                  Save Learning Preferences
                </Button>
              </CardContent>
            </Card>
          </section>

          {/* Privacy Settings */}
          <section id="privacy" className={`${isVisible ? "fade-in-up stagger-3 animate" : "fade-in-up stagger-3"}`}>
            <Card className="gradient-card">
              <CardHeader className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg flex items-center justify-center">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-foreground text-2xl">Privacy Settings</CardTitle>
                    <p className="text-muted-foreground">Control your privacy and data sharing preferences</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6 px-6 pb-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-6">
                    <div>
                      <Label htmlFor="profile-visibility" className="text-foreground mb-2 block">
                        Profile Visibility
                      </Label>
                      <Select value={profileVisibility} onValueChange={setProfileVisibility}>
                        <SelectTrigger className="bg-input border-border text-foreground">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="gradient-card border-border">
                          <SelectItem value="public">Public - Anyone can see your profile</SelectItem>
                          <SelectItem value="members">Members Only - Only SkillSwap members</SelectItem>
                          <SelectItem value="private">Private - Only people you connect with</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="allow-messages" className="text-foreground mb-2 block">
                        Who Can Message You
                      </Label>
                      <Select value={allowMessages} onValueChange={setAllowMessages}>
                        <SelectTrigger className="bg-input border-border text-foreground">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="gradient-card border-border">
                          <SelectItem value="everyone">Everyone</SelectItem>
                          <SelectItem value="members">Members Only</SelectItem>
                          <SelectItem value="connections">Connections Only</SelectItem>
                          <SelectItem value="none">No One</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-4">
                      <h4 className="text-foreground font-semibold flex items-center gap-2">
                        <Eye className="h-4 w-4" />
                        Visibility Options
                      </h4>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-foreground">Show Online Status</Label>
                          <p className="text-sm text-muted-foreground">Let others see when you're online</p>
                        </div>
                        <Switch checked={showOnlineStatus} onCheckedChange={setShowOnlineStatus} />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-foreground">Show Skills Publicly</Label>
                          <p className="text-sm text-muted-foreground">Display your skills on your public profile</p>
                        </div>
                        <Switch checked={showSkillsPublicly} onCheckedChange={setShowSkillsPublicly} />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-foreground">Data Sharing</Label>
                          <p className="text-sm text-muted-foreground">Share anonymized data to improve the platform</p>
                        </div>
                        <Switch checked={dataSharing} onCheckedChange={setDataSharing} />
                      </div>
                    </div>
                  </div>
                </div>

                <Separator className="bg-border" />

                <Button onClick={savePrivacySettings} className="gradient-button">
                  <Save className="h-4 w-4 mr-2" />
                  Save Privacy Settings
                </Button>
              </CardContent>
            </Card>
          </section>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 pt-8 border-t border-border">
          <p className="text-muted-foreground">
            Need help? Contact our support team or check out our{" "}
            <Link href="/help" className="text-primary hover:underline">
              Help Center
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}

export default SettingsPage
