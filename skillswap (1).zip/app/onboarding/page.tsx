"use client"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Users, User, BookOpen, Plus, X } from "lucide-react"
import { useRouter } from "next/navigation"

export default function OnboardingPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  // Form data
  const [bio, setBio] = useState("")
  const [profilePicture, setProfilePicture] = useState<File | null>(null)
  const [skillsToTeach, setSkillsToTeach] = useState<string[]>([])
  const [skillsToLearn, setSkillsToLearn] = useState<string[]>([])
  const [newSkillToTeach, setNewSkillToTeach] = useState("")
  const [newSkillToLearn, setNewSkillToLearn] = useState("")

  const totalSteps = 3
  const progress = (currentStep / totalSteps) * 100

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const addSkillToTeach = () => {
    if (newSkillToTeach.trim() && !skillsToTeach.includes(newSkillToTeach.trim())) {
      setSkillsToTeach([...skillsToTeach, newSkillToTeach.trim()])
      setNewSkillToTeach("")
    }
  }

  const addSkillToLearn = () => {
    if (newSkillToLearn.trim() && !skillsToLearn.includes(newSkillToLearn.trim())) {
      setSkillsToLearn([...skillsToLearn, newSkillToLearn.trim()])
      setNewSkillToLearn("")
    }
  }

  const removeSkillToTeach = (skill: string) => {
    setSkillsToTeach(skillsToTeach.filter((s) => s !== skill))
  }

  const removeSkillToLearn = (skill: string) => {
    setSkillsToLearn(skillsToLearn.filter((s) => s !== skill))
  }

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleComplete = async () => {
    setIsLoading(true)

    // Simulate saving user profile data
    setTimeout(() => {
      setIsLoading(false)
      const userData = {
        bio,
        profilePicture: profilePicture?.name || null,
        skillsToTeach,
        skillsToLearn,
        onboardingComplete: true,
        points: 0,
        skillsTaught: 0,
        skillsLearned: 0,
        totalExchanges: 0,
      }
      localStorage.setItem("userData", JSON.stringify(userData))

      // Redirect to dashboard
      router.push("/dashboard")
    }, 1500)
  }

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return bio.trim().length > 0
      case 2:
        return true // Profile picture is optional
      case 3:
        return skillsToTeach.length > 0 && skillsToLearn.length > 0
      default:
        return false
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-primary/5"></div>
      <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-primary/20 to-primary/5 rounded-full blur-3xl float"></div>
      <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-primary/15 to-primary/5 rounded-full blur-3xl float"></div>

      <div
        className={`relative w-full max-w-2xl transition-all duration-1000 ${
          isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4 fade-in-up stagger-1">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-lg flex items-center justify-center pulse-glow">
              <Users className="w-6 h-6 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground float">SkillSwap</h1>
          </div>
          <h2 className="text-3xl font-bold text-foreground mb-2 scale-in stagger-2">Welcome to the Network!</h2>
          <p className="text-muted-foreground fade-in-up stagger-3">Let's set up your professional profile</p>
        </div>

        <div className="mb-8 fade-in-up stagger-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-muted-foreground">
              Step {currentStep} of {totalSteps}
            </span>
            <span className="text-sm font-medium text-primary">{Math.round(progress)}% Complete</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div
              className="bg-gradient-to-r from-primary to-primary/80 h-2 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="gradient-card shadow-xl scale-in stagger-5">
          <CardHeader className="text-center">
            {currentStep === 1 && (
              <>
                <div className="w-16 h-16 bg-gradient-to-br from-primary/30 to-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 pulse-glow fade-in-up stagger-1">
                  <User className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-2xl text-foreground fade-in-up stagger-2">
                  Professional Introduction
                </CardTitle>
                <CardDescription className="text-muted-foreground fade-in-up stagger-3">
                  Share your background and expertise with the community
                </CardDescription>
              </>
            )}
            {currentStep === 2 && (
              <>
                <div className="w-16 h-16 bg-gradient-to-br from-primary/30 to-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 pulse-glow fade-in-up stagger-1">
                  <User className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-2xl text-foreground fade-in-up stagger-2">Profile Photo</CardTitle>
                <CardDescription className="text-muted-foreground fade-in-up stagger-3">
                  Add a professional photo to build trust (optional)
                </CardDescription>
              </>
            )}
            {currentStep === 3 && (
              <>
                <div className="w-16 h-16 bg-gradient-to-br from-primary/30 to-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 pulse-glow fade-in-up stagger-1">
                  <BookOpen className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-2xl text-foreground fade-in-up stagger-2">
                  Expertise & Learning Goals
                </CardTitle>
                <CardDescription className="text-muted-foreground fade-in-up stagger-3">
                  Define your skills and learning objectives
                </CardDescription>
              </>
            )}
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Step 1: Bio */}
            {currentStep === 1 && (
              <div className="space-y-4 fade-in-up stagger-4">
                <div className="space-y-2">
                  <Label htmlFor="bio" className="text-foreground">
                    Professional Bio
                  </Label>
                  <Textarea
                    id="bio"
                    placeholder="Describe your professional background, expertise, and what you're looking to achieve through SkillSwap..."
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    className="min-h-32 bg-input border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary transition-all duration-300"
                    maxLength={500}
                  />
                  <p className="text-sm text-muted-foreground text-right">{bio.length}/500 characters</p>
                </div>
              </div>
            )}

            {/* Step 2: Profile Picture */}
            {currentStep === 2 && (
              <div className="space-y-4 fade-in-up stagger-4">
                <div className="space-y-2">
                  <Label htmlFor="profile-picture" className="text-foreground">
                    Profile Picture
                  </Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-all duration-300 hover:bg-primary/5">
                    <User className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <Input
                      id="profile-picture"
                      type="file"
                      accept="image/*"
                      onChange={(e) => setProfilePicture(e.target.files?.[0] || null)}
                      className="hidden"
                    />
                    <Label
                      htmlFor="profile-picture"
                      className="cursor-pointer inline-flex items-center gap-2 gradient-button transition-all duration-300 hover:scale-105"
                    >
                      Choose Photo
                    </Label>
                    {profilePicture && (
                      <p className="text-sm text-muted-foreground mt-2">Selected: {profilePicture.name}</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Skills */}
            {currentStep === 3 && (
              <div className="space-y-6">
                {/* Skills to Teach */}
                <div className="space-y-3 fade-in-left stagger-1">
                  <Label className="text-base font-semibold text-foreground">Skills I can teach</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="e.g., Web Development, Data Analysis, Project Management"
                      value={newSkillToTeach}
                      onChange={(e) => setNewSkillToTeach(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkillToTeach())}
                      className="bg-input border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary transition-all duration-300"
                    />
                    <Button
                      type="button"
                      onClick={addSkillToTeach}
                      className="gradient-button px-4 hover:scale-105 transition-all duration-300"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {skillsToTeach.map((skill, index) => (
                      <Badge
                        key={skill}
                        variant="secondary"
                        className={`bg-gradient-to-r from-primary/20 to-primary/10 text-primary hover:from-primary/30 hover:to-primary/20 border-primary/20 transition-all duration-300 fade-in-up stagger-${index + 1}`}
                      >
                        {skill}
                        <button
                          onClick={() => removeSkillToTeach(skill)}
                          className="ml-2 hover:text-primary/70 transition-colors duration-300"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Skills to Learn */}
                <div className="space-y-3 fade-in-right stagger-2">
                  <Label className="text-base font-semibold text-foreground">Skills I want to learn</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="e.g., Machine Learning, Design Thinking, Leadership"
                      value={newSkillToLearn}
                      onChange={(e) => setNewSkillToLearn(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkillToLearn())}
                      className="bg-input border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary transition-all duration-300"
                    />
                    <Button
                      type="button"
                      onClick={addSkillToLearn}
                      className="bg-secondary hover:bg-secondary/80 text-secondary-foreground px-4 hover:scale-105 transition-all duration-300"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {skillsToLearn.map((skill, index) => (
                      <Badge
                        key={skill}
                        variant="secondary"
                        className={`bg-secondary/50 text-foreground hover:bg-secondary border-border transition-all duration-300 fade-in-up stagger-${index + 1}`}
                      >
                        {skill}
                        <button
                          onClick={() => removeSkillToLearn(skill)}
                          className="ml-2 hover:text-muted-foreground/70 transition-colors duration-300"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-between pt-6 fade-in-up stagger-6">
              <Button
                variant="outline"
                onClick={handleBack}
                disabled={currentStep === 1}
                className="border-border text-foreground hover:bg-secondary bg-transparent transition-all duration-300 hover:scale-105"
              >
                Back
              </Button>

              {currentStep < totalSteps ? (
                <Button
                  onClick={handleNext}
                  disabled={!canProceed()}
                  className="gradient-button pulse-glow hover:scale-105 transition-all duration-300"
                >
                  Next Step
                </Button>
              ) : (
                <Button
                  onClick={handleComplete}
                  disabled={!canProceed() || isLoading}
                  className="gradient-button pulse-glow hover:scale-105 transition-all duration-300"
                >
                  {isLoading ? "Setting up your profile..." : "Complete Setup"}
                </Button>
              )}
            </div>
          </CardContent>
        </div>
      </div>
    </div>
  )
}
