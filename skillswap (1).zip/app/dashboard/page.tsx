"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  MessageCircle,
  Users,
  Trophy,
  Plus,
  X,
  Send,
  Settings,
  User,
  LogOut,
  Edit,
  MapPin,
  Monitor,
  Users2,
  ChevronDown,
} from "lucide-react"
import { useUser } from "@/hooks/use-user"
import { useMessaging } from "@/hooks/use-messaging"
import { getAllUsers } from "@/lib/user-data"
import { formatMessageTime, formatChatTime } from "@/lib/messaging"

const DashboardPage = () => {
  const { currentUser, updateUser, userStats } = useUser()
  const { conversations, messages, sendMessage, selectConversation, selectedConversation, unreadCount } = useMessaging(
    currentUser?.id,
  )
  const router = useRouter()

  const [newTeachSkill, setNewTeachSkill] = useState("")
  const [newLearnSkill, setNewLearnSkill] = useState("")
  const [bio, setBio] = useState(currentUser?.bio || "")
  const [messageText, setMessageText] = useState("")
  const [isVisible, setIsVisible] = useState(false)

  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false)
  const [editName, setEditName] = useState(currentUser?.name || "")
  const [editEmail, setEditEmail] = useState(currentUser?.email || "")
  const [editLocation, setEditLocation] = useState(currentUser?.location || "")
  const [editLearningMode, setEditLearningMode] = useState(currentUser?.learningMode || "both")

  useEffect(() => {
    setIsVisible(true)
  }, [])

  useEffect(() => {
    if (currentUser) {
      setEditName(currentUser.name || "")
      setEditEmail(currentUser.email || "")
      setEditLocation(currentUser.location || "")
      setEditLearningMode(currentUser.learningMode || "both")
      setBio(currentUser.bio || "")
    }
  }, [currentUser])

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="gradient-card p-8 text-center max-w-md scale-in">
          <h2 className="text-2xl font-bold text-foreground mb-4">Please sign in to access your dashboard</h2>
          <Link href="/auth">
            <Button className="gradient-button pulse-glow">Sign In</Button>
          </Link>
        </div>
      </div>
    )
  }

  const updateProfile = () => {
    updateUser({
      ...currentUser,
      name: editName,
      email: editEmail,
      location: editLocation,
      learningMode: editLearningMode,
    })
    setIsProfileModalOpen(false)
  }

  const handleLogout = () => {
    localStorage.removeItem("authData")
    localStorage.removeItem("userData")
    router.push("/")
  }

  const addTeachSkill = () => {
    if (newTeachSkill.trim() && !currentUser.skillsToTeach.includes(newTeachSkill.trim())) {
      updateUser({
        ...currentUser,
        skillsToTeach: [...currentUser.skillsToTeach, newTeachSkill.trim()],
      })
      setNewTeachSkill("")
    }
  }

  const removeTeachSkill = (skill) => {
    updateUser({
      ...currentUser,
      skillsToTeach: currentUser.skillsToTeach.filter((s) => s !== skill),
    })
  }

  const addLearnSkill = () => {
    if (newLearnSkill.trim() && !currentUser.skillsToLearn.includes(newLearnSkill.trim())) {
      updateUser({
        ...currentUser,
        skillsToLearn: [...currentUser.skillsToLearn, newLearnSkill.trim()],
      })
      setNewLearnSkill("")
    }
  }

  const removeLearnSkill = (skill) => {
    updateUser({
      ...currentUser,
      skillsToLearn: currentUser.skillsToLearn.filter((s) => s !== skill),
    })
  }

  const saveBio = () => {
    updateUser({
      ...currentUser,
      bio: bio,
    })
  }

  const handleSendMessage = () => {
    if (messageText.trim() && selectedConversation) {
      sendMessage(selectedConversation, messageText.trim())
      setMessageText("")
    }
  }

  const allUsers = getAllUsers()
  const leaderboard = allUsers
    .map((user) => ({
      ...user,
      points: user.skillsToTeach.length * 500,
    }))
    .sort((a, b) => b.points - a.points)
    .slice(0, 100)

  const getOtherUser = (conversation) => {
    const otherUserId = conversation.participants.find((id) => id !== currentUser.id)
    return allUsers.find((user) => user.id === otherUserId)
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/10"></div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-8 relative z-10">
        <div
          className={`flex items-center justify-between mb-12 transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0 float animate" : "opacity-0 translate-y-8 float"
          }`}
        >
          <Link href="/" className="text-3xl font-bold text-foreground hover:text-primary transition-colors">
            SkillSwap
          </Link>
          <div className={`flex items-center gap-6 ${isVisible ? "fade-in-right animate" : "fade-in-right"}`}>
            <Avatar className="h-16 w-16 ring-2 ring-primary/20 pulse-glow">
              <AvatarImage src={currentUser.profilePicture || "/placeholder.svg"} alt={currentUser.name} />
              <AvatarFallback className="bg-secondary text-secondary-foreground text-lg font-semibold">
                {currentUser.name
                  ?.split(" ")
                  .map((n) => n[0])
                  .join("") || "?"}
              </AvatarFallback>
            </Avatar>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-2 hover:bg-secondary/20 rounded-lg p-2 transition-colors cursor-pointer group">
                <div>
                  <h2 className="text-2xl font-bold text-foreground group-hover:text-primary transition-colors">
                    {currentUser.name}
                  </h2>
                  <p className="text-muted-foreground">{currentUser.email}</p>
                </div>
                <ChevronDown className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </DropdownMenuTrigger>

              <DropdownMenuContent align="end" className="w-64 gradient-card border-border">
                <div className="px-3 py-2 border-b border-border">
                  <p className="font-semibold text-foreground">{currentUser.name}</p>
                  <p className="text-sm text-muted-foreground">{currentUser.email}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <MapPin className="h-3 w-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{currentUser.location || "Location not set"}</span>
                  </div>
                </div>

                <Dialog open={isProfileModalOpen} onOpenChange={setIsProfileModalOpen}>
                  <DialogTrigger asChild>
                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                      <User className="h-4 w-4 mr-2" />
                      Edit Profile
                    </DropdownMenuItem>
                  </DialogTrigger>
                  <DialogContent className="gradient-card border-border max-w-md">
                    <DialogHeader>
                      <DialogTitle className="text-foreground flex items-center gap-2">
                        <Edit className="h-5 w-5" />
                        Edit Profile
                      </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 pt-4">
                      <div>
                        <Label htmlFor="name" className="text-foreground mb-2 block">
                          Name
                        </Label>
                        <Input
                          id="name"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="bg-input border-border text-foreground"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email" className="text-foreground mb-2 block">
                          Email
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={editEmail}
                          onChange={(e) => setEditEmail(e.target.value)}
                          className="bg-input border-border text-foreground"
                        />
                      </div>
                      <div>
                        <Label htmlFor="location" className="text-foreground mb-2 block">
                          Location
                        </Label>
                        <Input
                          id="location"
                          value={editLocation}
                          onChange={(e) => setEditLocation(e.target.value)}
                          placeholder="e.g., San Francisco, CA"
                          className="bg-input border-border text-foreground"
                        />
                      </div>
                      <div>
                        <Label htmlFor="learningMode" className="text-foreground mb-2 block">
                          Learning Preference
                        </Label>
                        <Select value={editLearningMode} onValueChange={setEditLearningMode}>
                          <SelectTrigger className="bg-input border-border text-foreground">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="gradient-card border-border">
                            <SelectItem value="online">Online Only</SelectItem>
                            <SelectItem value="physical">Physical Only</SelectItem>
                            <SelectItem value="both">Both Online & Physical</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex gap-3 pt-4">
                        <Button onClick={updateProfile} className="gradient-button flex-1">
                          Save Changes
                        </Button>
                        <Button variant="outline" onClick={() => setIsProfileModalOpen(false)} className="flex-1">
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>

                <Link href="/settings?section=account">
                  <DropdownMenuItem>
                    <Settings className="h-4 w-4 mr-2" />
                    Account Settings
                  </DropdownMenuItem>
                </Link>

                <Link href="/settings?section=learning">
                  <DropdownMenuItem>
                    <Monitor className="h-4 w-4 mr-2" />
                    Learning Preferences
                  </DropdownMenuItem>
                </Link>

                <Link href="/settings?section=privacy">
                  <DropdownMenuItem>
                    <Users2 className="h-4 w-4 mr-2" />
                    Privacy Settings
                  </DropdownMenuItem>
                </Link>

                <DropdownMenuSeparator className="bg-border" />

                <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive">
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className={`gradient-card group ${isVisible ? "fade-in-up stagger-1 animate" : "fade-in-up stagger-1"}`}>
            <div className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm font-medium mb-2">Total Points</p>
                  <p className="text-3xl font-bold text-foreground">{userStats.points}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center group-hover:from-primary/30 group-hover:to-primary/20 transition-all duration-300 pulse-glow">
                  <Trophy className="h-6 w-6 text-primary" />
                </div>
              </div>
            </div>
          </div>

          <div className={`gradient-card group ${isVisible ? "fade-in-up stagger-2 animate" : "fade-in-up stagger-2"}`}>
            <div className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm font-medium mb-2">Skills Teaching</p>
                  <p className="text-3xl font-bold text-foreground">{userStats.skillsTaught}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center group-hover:from-primary/30 group-hover:to-primary/20 transition-all duration-300 pulse-glow">
                  <Users className="h-6 w-6 text-primary" />
                </div>
              </div>
            </div>
          </div>

          <div className={`gradient-card group ${isVisible ? "fade-in-up stagger-3 animate" : "fade-in-up stagger-3"}`}>
            <div className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm font-medium mb-2">Skills Learning</p>
                  <p className="text-3xl font-bold text-foreground">{userStats.skillsLearned}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center group-hover:from-primary/30 group-hover:to-primary/20 transition-all duration-300 pulse-glow">
                  <Users className="h-6 w-6 text-primary" />
                </div>
              </div>
            </div>
          </div>

          <div className={`gradient-card group ${isVisible ? "fade-in-up stagger-4 animate" : "fade-in-up stagger-4"}`}>
            <div className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm font-medium mb-2">Messages</p>
                  <p className="text-3xl font-bold text-foreground">{unreadCount}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl flex items-center justify-center group-hover:from-primary/30 group-hover:to-primary/20 transition-all duration-300 pulse-glow">
                  <MessageCircle className="h-6 w-6 text-primary" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <Tabs
          defaultValue="exchange"
          className={`w-full ${isVisible ? "fade-in-up stagger-5 animate" : "fade-in-up stagger-5"}`}
        >
          <TabsList className="grid w-full grid-cols-3 bg-gradient-to-r from-card/80 to-card/60 backdrop-blur-sm border border-border rounded-xl p-1 mb-8 h-12">
            <TabsTrigger
              value="exchange"
              className="text-foreground data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-primary/80 data-[state=active]:text-primary-foreground font-semibold rounded-lg transition-all duration-300 h-10 mx-0.5"
            >
              Exchange
            </TabsTrigger>
            <TabsTrigger
              value="messages"
              className="text-foreground data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-primary/80 data-[state=active]:text-primary-foreground font-semibold rounded-lg transition-all duration-300 h-10 mx-0.5"
            >
              Messages
            </TabsTrigger>
            <TabsTrigger
              value="leaderboards"
              className="text-foreground data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-primary/80 data-[state=active]:text-primary-foreground font-semibold rounded-lg transition-all duration-300 h-10 mx-0.5"
            >
              Leaderboards
            </TabsTrigger>
          </TabsList>

          <TabsContent value="exchange" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div
                className={`gradient-card ${isVisible ? "fade-in-left stagger-1 animate" : "fade-in-left stagger-1"}`}
              >
                <CardHeader className="pb-4 pt-6">
                  <CardTitle className="text-foreground text-xl">Skills I Can Teach</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6 px-6 pb-6">
                  <div className="flex flex-wrap gap-3">
                    {currentUser.skillsToTeach.map((skill, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="bg-gradient-to-r from-primary/20 to-primary/10 text-primary hover:from-primary/30 hover:to-primary/20 px-3 py-1 text-sm transition-all duration-300"
                      >
                        {skill}
                        <button onClick={() => removeTeachSkill(skill)} className="ml-2 hover:text-destructive">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <Input
                      placeholder="Add a skill you can teach..."
                      value={newTeachSkill}
                      onChange={(e) => setNewTeachSkill(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && addTeachSkill()}
                      className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                    />
                    <Button onClick={addTeachSkill} size="sm" className="gradient-button">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </div>

              <div
                className={`gradient-card ${isVisible ? "fade-in-right stagger-2 animate" : "fade-in-right stagger-2"}`}
              >
                <CardHeader className="pb-4 pt-6">
                  <CardTitle className="text-foreground text-xl">Skills I Want to Learn</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6 px-6 pb-6">
                  <div className="flex flex-wrap gap-3">
                    {currentUser.skillsToLearn.map((skill, index) => (
                      <Badge
                        key={index}
                        variant="outline"
                        className="border-border text-foreground hover:bg-secondary px-3 py-1 text-sm transition-all duration-300"
                      >
                        {skill}
                        <button onClick={() => removeLearnSkill(skill)} className="ml-2 hover:text-destructive">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <Input
                      placeholder="Add a skill you want to learn..."
                      value={newLearnSkill}
                      onChange={(e) => setNewLearnSkill(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && addLearnSkill()}
                      className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                    />
                    <Button onClick={addLearnSkill} size="sm" className="gradient-button">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </div>
            </div>

            <div className={`gradient-card ${isVisible ? "fade-in-up stagger-3 animate" : "fade-in-up stagger-3"}`}>
              <CardHeader className="pb-4 pt-6">
                <CardTitle className="text-foreground text-xl">About Me</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6 px-6 pb-6">
                <Textarea
                  placeholder="Tell others about yourself, your experience, and what you're passionate about..."
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="bg-input border-border text-foreground placeholder:text-muted-foreground min-h-[120px] resize-none"
                />
                <Button onClick={saveBio} className="gradient-button pulse-glow">
                  Save Bio
                </Button>
              </CardContent>
            </div>

            <div
              className={`gradient-card text-center p-12 relative overflow-hidden ${isVisible ? "fade-in-up stagger-4 animate" : "fade-in-up stagger-4"}`}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10"></div>
              <div className="relative z-10">
                <h3
                  className={`text-3xl font-bold text-foreground mb-4 ${isVisible ? "scale-in animate" : "scale-in"}`}
                >
                  Ready to Connect?
                </h3>
                <p
                  className={`text-xl text-muted-foreground mb-8 max-w-2xl mx-auto ${isVisible ? "fade-in-up stagger-1 animate" : "fade-in-up stagger-1"}`}
                >
                  Browse other professionals and start exchanging skills to accelerate your growth
                </p>
                <Link href="/exchange">
                  <Button className="gradient-button text-lg px-8 py-4 pulse-glow hover:scale-105 transition-all duration-300">
                    Browse Professionals
                  </Button>
                </Link>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="messages">
            {!conversations || conversations.length === 0 ? (
              <div className={`gradient-card text-center p-12 ${isVisible ? "scale-in animate" : "scale-in"}`}>
                <MessageCircle
                  className={`w-20 h-20 text-muted-foreground mx-auto mb-6 ${isVisible ? "float animate" : "float"}`}
                />
                <h3 className="text-2xl font-bold text-foreground mb-4">No Messages Yet</h3>
                <p className="text-lg text-muted-foreground mb-8">
                  Start connecting with other professionals to see your conversations here
                </p>
                <Link href="/exchange">
                  <Button className="gradient-button pulse-glow">Browse Professionals</Button>
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[700px]">
                <div className="gradient-card lg:col-span-1">
                  <CardHeader className="border-b border-border px-6 py-4 pt-6">
                    <CardTitle className="text-foreground">Messages</CardTitle>
                    <p className="text-sm text-muted-foreground">{conversations.length} conversations</p>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="overflow-y-auto h-[580px]">
                      {conversations.map((conversation) => {
                        const otherUser = getOtherUser(conversation)
                        if (!otherUser) return null

                        return (
                          <div
                            key={conversation.id}
                            className={`p-4 border-b border-border cursor-pointer transition-all duration-300 hover:bg-gradient-to-r hover:from-secondary/30 hover:to-secondary/10 ${
                              selectedConversation === otherUser.id
                                ? "bg-gradient-to-r from-secondary/50 to-secondary/20"
                                : ""
                            }`}
                            onClick={() => selectConversation(otherUser.id)}
                          >
                            <div className="flex items-center gap-3">
                              <div className="relative">
                                <Avatar className="h-12 w-12">
                                  <AvatarImage
                                    src={otherUser.profilePicture || "/placeholder.svg"}
                                    alt={otherUser.name}
                                  />
                                  <AvatarFallback className="bg-secondary text-secondary-foreground">
                                    {otherUser.name
                                      ?.split(" ")
                                      .map((n) => n[0])
                                      .join("") || "?"}
                                  </AvatarFallback>
                                </Avatar>
                                {otherUser.isOnline && (
                                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-primary rounded-full border-2 border-background pulse-glow"></div>
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between">
                                  <p className="font-semibold text-foreground truncate">{otherUser.name}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {formatMessageTime(conversation.lastMessage.timestamp)}
                                  </p>
                                </div>
                                <p className="text-sm text-muted-foreground truncate">
                                  {conversation.lastMessage.content}
                                </p>
                              </div>
                              {conversation.unreadCount > 0 && (
                                <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground text-xs rounded-full px-2 py-1 font-semibold pulse-glow">
                                  {conversation.unreadCount}
                                </div>
                              )}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </div>

                <div className="gradient-card lg:col-span-2 flex flex-col">
                  {selectedConversation ? (
                    <>
                      <CardHeader className="border-b border-border bg-gradient-to-r from-card/50 to-card/30 px-6 py-4 pt-6">
                        {(() => {
                          const otherUser = allUsers.find((user) => user.id === selectedConversation)
                          return otherUser ? (
                            <>
                              <Avatar className="h-12 w-12 pulse-glow">
                                <AvatarImage
                                  src={otherUser.profilePicture || "/placeholder.svg"}
                                  alt={otherUser.name}
                                />
                                <AvatarFallback className="bg-secondary text-secondary-foreground">
                                  {otherUser.name
                                    ?.split(" ")
                                    .map((n) => n[0])
                                    .join("") || "?"}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-semibold text-foreground">{otherUser.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  {otherUser.isOnline ? "Online" : "Last seen recently"}
                                </p>
                              </div>
                            </>
                          ) : null
                        })()}
                      </CardHeader>

                      <CardContent className="flex-1 px-6 py-4 space-y-4 overflow-y-auto">
                        {messages.map((message) => (
                          <div
                            key={message.id}
                            className={`flex ${message.senderId === currentUser.id ? "justify-end" : "justify-start"}`}
                          >
                            <div
                              className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl transition-all duration-300 hover:scale-105 ${
                                message.senderId === currentUser.id
                                  ? "bg-gradient-to-r from-primary to-primary/80 text-primary-foreground rounded-br-md"
                                  : "bg-gradient-to-r from-secondary to-secondary/80 text-secondary-foreground rounded-bl-md"
                              }`}
                            >
                              <p className="text-sm">{message.content}</p>
                              <p className="text-xs mt-1 opacity-70">{formatChatTime(message.timestamp)}</p>
                            </div>
                          </div>
                        ))}
                      </CardContent>

                      <div className="px-6 py-4 border-t border-border bg-gradient-to-r from-card/30 to-card/10">
                        <div className="flex gap-3">
                          <Input
                            placeholder="Type a message..."
                            value={messageText}
                            onChange={(e) => setMessageText(e.target.value)}
                            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                            className="bg-input border-border text-foreground placeholder:text-muted-foreground rounded-full"
                          />
                          <Button
                            onClick={handleSendMessage}
                            disabled={!messageText.trim()}
                            className="gradient-button rounded-full px-4 pulse-glow"
                          >
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center justify-center h-full text-center">
                      <div className="scale-in">
                        <MessageCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4 float" />
                        <p className="text-muted-foreground text-lg">Select a conversation to start messaging</p>
                        <p className="text-muted-foreground/60 text-sm mt-2">
                          Choose from your existing conversations on the left
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="leaderboards">
            <div className={`gradient-card ${isVisible ? "fade-in-up animate" : "fade-in-up"}`}>
              <CardHeader className="text-center pb-6 pt-6">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <Trophy className="h-8 w-8 text-primary pulse-glow" />
                  <CardTitle className="text-3xl font-bold text-foreground">Leaderboards</CardTitle>
                  <Trophy className="h-8 w-8 text-primary pulse-glow" />
                </div>
                <p className="text-muted-foreground text-lg">Top performers in our skill-sharing community</p>
              </CardHeader>
              <CardContent className="px-6 pb-6">
                <div className="space-y-4">
                  {leaderboard.slice(0, 10).map((user, index) => {
                    const isCurrentUser = user.id === currentUser.id
                    const isTop3 = index < 3
                    const crownColors = {
                      0: "text-yellow-500", // Gold
                      1: "text-gray-400", // Silver
                      2: "text-amber-600", // Bronze
                    }

                    return (
                      <div
                        key={user.id}
                        className={`gradient-card p-6 transition-all duration-300 hover:scale-[1.02] cursor-pointer group ${
                          isCurrentUser ? "ring-2 ring-primary/50 bg-gradient-to-r from-primary/10 to-primary/5" : ""
                        } ${isVisible ? `fade-in-up stagger-${index + 1} animate` : `fade-in-up stagger-${index + 1}`}`}
                        onClick={() => {
                          if (!isCurrentUser) {
                            // Create a new conversation with this user
                            sendMessage(
                              user.id,
                              `Hi ${user.name}! I saw your profile on the leaderboards and would love to connect about skill sharing.`,
                            )
                          }
                        }}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="relative">
                              <div
                                className={`text-2xl font-bold w-12 h-12 rounded-full flex items-center justify-center ${
                                  isTop3 ? "bg-gradient-to-br from-primary/20 to-primary/10" : "bg-secondary"
                                }`}
                              >
                                {index + 1}
                              </div>
                              {isTop3 && (
                                <div className={`absolute -top-2 -right-2 ${crownColors[index]} pulse-glow`}>
                                  <Trophy className="h-6 w-6" />
                                </div>
                              )}
                            </div>

                            <Avatar className="h-16 w-16 ring-2 ring-primary/20">
                              <AvatarImage src={user.profilePicture || "/placeholder.svg"} alt={user.name} />
                              <AvatarFallback className="bg-secondary text-secondary-foreground text-lg font-semibold">
                                {user.name
                                  ?.split(" ")
                                  .map((n) => n[0])
                                  .join("") || "?"}
                              </AvatarFallback>
                            </Avatar>

                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <h3 className="text-xl font-bold text-foreground">{user.name}</h3>
                                {isCurrentUser && (
                                  <Badge className="bg-gradient-to-r from-primary/20 to-primary/10 text-primary">
                                    You
                                  </Badge>
                                )}
                                {user.isOnline && (
                                  <div className="flex items-center gap-1">
                                    <div className="w-2 h-2 bg-primary rounded-full pulse-glow"></div>
                                    <span className="text-xs text-primary">Online</span>
                                  </div>
                                )}
                              </div>
                              <p className="text-muted-foreground">{user.location}</p>
                              <div className="flex flex-wrap gap-2 mt-2">
                                {user.skillsToTeach.slice(0, 3).map((skill, skillIndex) => (
                                  <Badge
                                    key={skillIndex}
                                    variant="secondary"
                                    className="text-xs bg-gradient-to-r from-primary/20 to-primary/10 text-primary"
                                  >
                                    {skill}
                                  </Badge>
                                ))}
                                {user.skillsToTeach.length > 3 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{user.skillsToTeach.length - 3} more
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="text-right">
                            <div className="flex items-center gap-2 mb-2">
                              <Trophy className="h-5 w-5 text-primary" />
                              <span className="text-2xl font-bold text-foreground">{user.points}</span>
                              <span className="text-sm text-muted-foreground">pts</span>
                            </div>
                            <p className="text-sm text-muted-foreground">{user.skillsToTeach.length} skills teaching</p>
                            {!isCurrentUser && (
                              <div className="mt-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                <Button size="sm" className="gradient-button text-xs">
                                  <MessageCircle className="h-3 w-3 mr-1" />
                                  Connect
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>

                <div className="text-center mt-8 pt-6 border-t border-border">
                  <p className="text-muted-foreground">
                    Keep teaching skills to climb the leaderboards! Each skill you teach earns you 500 points.
                  </p>
                </div>
              </CardContent>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default DashboardPage
