"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Users, BookOpen, Eye, EyeOff } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { validatePassword, getPasswordStrengthColor, getPasswordStrengthBg } from "@/lib/password-validation"

export default function AuthPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [loginData, setLoginData] = useState({ email: "", password: "" })
  const [signupData, setSignupData] = useState({ name: "", email: "", password: "" })
  const [showPassword, setShowPassword] = useState(false)
  const [passwordValidation, setPasswordValidation] = useState(validatePassword(""))
  const [isVisible, setIsVisible] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      const storedAuth = localStorage.getItem("authData")
      if (storedAuth) {
        const authData = JSON.parse(storedAuth)
        if (authData.email === loginData.email) {
          // User exists, redirect to dashboard immediately
          localStorage.setItem("authData", JSON.stringify(authData))
          router.push("/dashboard")
          return
        }
      }

      // User doesn't exist
      setError("No account found with this email. Please sign up first.")
      setIsLoading(false)
    } catch (error) {
      console.error("Login error:", error)
      setError("An unexpected error occurred. Please try again.")
      setIsLoading(false)
    }
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!passwordValidation.isValid) {
      setError("Please create a stronger password before continuing.")
      return
    }

    setIsLoading(true)
    setError("")

    try {
      const existingAuth = localStorage.getItem("authData")
      if (existingAuth) {
        const authData = JSON.parse(existingAuth)
        if (authData.email === signupData.email) {
          setError("An account with this email already exists. Please sign in instead.")
          setIsLoading(false)
          return
        }
      }

      // Create new user
      const newAuthData = {
        id: `user-${Date.now()}`,
        name: signupData.name,
        email: signupData.email,
      }

      localStorage.setItem("authData", JSON.stringify(newAuthData))
      router.push("/onboarding")
    } catch (error) {
      console.error("Signup error:", error)
      setError("An unexpected error occurred. Please try again.")
      setIsLoading(false)
    }
  }

  const handlePasswordChange = (password: string) => {
    setSignupData({ ...signupData, password })
    setPasswordValidation(validatePassword(password))
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-primary/5"></div>
      <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-primary/20 to-primary/5 rounded-full blur-3xl float"></div>
      <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-primary/15 to-primary/5 rounded-full blur-3xl float"></div>

      <div
        className={`relative w-full max-w-md transition-all duration-1000 ${
          isVisible ? "opacity-100 translate-y-0 animate" : "opacity-0 translate-y-8"
        }`}
      >
        <Link
          href="/"
          className={`inline-flex items-center gap-2 text-foreground hover:text-primary mb-8 transition-all duration-300 hover:scale-105 fade-in-left ${isVisible ? "animate" : ""}`}
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        <div className={`gradient-card shadow-xl scale-in ${isVisible ? "animate" : ""}`}>
          <CardHeader className="text-center pb-4 pt-8">
            <div
              className={`flex items-center justify-center gap-4 mb-6 p-4 fade-in-up stagger-1 ${isVisible ? "animate" : ""}`}
            >
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center pulse-glow flex-shrink-0 shadow-lg">
                <Users className="w-7 h-7 text-primary-foreground" />
              </div>
              <h1 className="text-3xl font-bold text-foreground float leading-none">SkillSwap</h1>
            </div>
            <CardTitle className={`text-2xl text-foreground fade-in-up stagger-2 ${isVisible ? "animate" : ""}`}>
              Welcome Back
            </CardTitle>
            <CardDescription className={`text-muted-foreground fade-in-up stagger-3 ${isVisible ? "animate" : ""}`}>
              Access your professional learning network
            </CardDescription>
          </CardHeader>

          <CardContent className={`fade-in-up stagger-4 pb-8 ${isVisible ? "animate" : ""}`}>
            {error && (
              <div className="mb-4 p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive text-sm">
                {error}
              </div>
            )}

            {success && (
              <div className="mb-4 p-3 bg-green-500/10 border border-green-500/20 rounded-lg text-green-600 text-sm">
                {success}
              </div>
            )}

            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6 bg-gradient-to-r from-card/80 to-card/60 backdrop-blur-sm border border-border h-14 p-1">
                <TabsTrigger
                  value="login"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-primary/80 data-[state=active]:text-primary-foreground text-foreground transition-all duration-300 h-11 rounded-lg font-medium"
                >
                  Sign In
                </TabsTrigger>
                <TabsTrigger
                  value="signup"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-primary/80 data-[state=active]:text-primary-foreground text-foreground transition-all duration-300 h-11 rounded-lg font-medium"
                >
                  Sign Up
                </TabsTrigger>
              </TabsList>

              {/* Login Form */}
              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className={`space-y-2 fade-in-left stagger-1 ${isVisible ? "animate" : ""}`}>
                    <Label htmlFor="login-email" className="text-foreground">
                      Email
                    </Label>
                    <Input
                      id="login-email"
                      type="email"
                      placeholder="Enter your email"
                      value={loginData.email}
                      onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                      required
                      className="bg-input border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary transition-all duration-300"
                    />
                  </div>
                  <div className={`space-y-2 fade-in-right stagger-2 ${isVisible ? "animate" : ""}`}>
                    <Label htmlFor="login-password" className="text-foreground">
                      Password
                    </Label>
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="Enter your password"
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      required
                      className="bg-input border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary transition-all duration-300"
                    />
                  </div>
                  <Button
                    type="submit"
                    className={`w-full gradient-button font-semibold py-2 pulse-glow hover:scale-105 transition-all duration-300 fade-in-up stagger-3 ${isVisible ? "animate" : ""}`}
                    disabled={isLoading}
                  >
                    {isLoading ? "Signing In..." : "Sign In"}
                  </Button>
                </form>
              </TabsContent>

              {/* Signup Form */}
              <TabsContent value="signup">
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className={`space-y-2 fade-in-left stagger-1 ${isVisible ? "animate" : ""}`}>
                    <Label htmlFor="signup-name" className="text-foreground">
                      Full Name
                    </Label>
                    <Input
                      id="signup-name"
                      type="text"
                      placeholder="Enter your full name"
                      value={signupData.name}
                      onChange={(e) => setSignupData({ ...signupData, name: e.target.value })}
                      required
                      className="bg-input border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary transition-all duration-300"
                    />
                  </div>
                  <div className={`space-y-2 fade-in-right stagger-2 ${isVisible ? "animate" : ""}`}>
                    <Label htmlFor="signup-email" className="text-foreground">
                      Email
                    </Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="Enter your email"
                      value={signupData.email}
                      onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                      required
                      className="bg-input border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary transition-all duration-300"
                    />
                  </div>
                  <div className={`space-y-2 fade-in-left stagger-3 ${isVisible ? "animate" : ""}`}>
                    <Label htmlFor="signup-password" className="text-foreground">
                      Password
                    </Label>
                    <div className="relative">
                      <Input
                        id="signup-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Create a password"
                        value={signupData.password}
                        onChange={(e) => handlePasswordChange(e.target.value)}
                        required
                        className="bg-input border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary pr-10 transition-all duration-300"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors duration-300"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>

                    {/* Password Strength Indicator */}
                    {signupData.password && (
                      <div className={`space-y-2 fade-in-up stagger-1 ${isVisible ? "animate" : ""}`}>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-secondary rounded-full h-2">
                            <div
                              className={`h-2 rounded-full transition-all duration-500 ${getPasswordStrengthBg(passwordValidation.strength)}`}
                              style={{ width: `${(passwordValidation.score / 6) * 100}%` }}
                            />
                          </div>
                          <span
                            className={`text-sm font-medium ${getPasswordStrengthColor(passwordValidation.strength)}`}
                          >
                            {passwordValidation.strength.charAt(0).toUpperCase() + passwordValidation.strength.slice(1)}
                          </span>
                        </div>

                        {passwordValidation.feedback.length > 0 && (
                          <div className="text-xs text-muted-foreground space-y-1">
                            {passwordValidation.feedback.map((item, index) => (
                              <div key={index}>• {item}</div>
                            ))}
                          </div>
                        )}

                        {!passwordValidation.isValid && (
                          <div className="text-xs text-destructive">
                            Password must be at least decent strength to continue
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  <Button
                    type="submit"
                    className={`w-full gradient-button font-semibold py-2 pulse-glow hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed fade-in-up stagger-4 ${isVisible ? "animate" : ""}`}
                    disabled={isLoading || !passwordValidation.isValid}
                  >
                    {isLoading ? "Creating Account..." : "Create Account"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            <div className={`mt-8 pt-6 pb-4 border-t border-border fade-in-up stagger-5 ${isVisible ? "animate" : ""}`}>
              <p className="text-sm text-muted-foreground text-center mb-6">Join the professional community:</p>
              <div className="flex items-center justify-center gap-12 text-sm px-4">
                <div
                  className={`flex items-center gap-3 text-foreground hover:text-primary transition-colors duration-300 fade-in-left stagger-1 ${isVisible ? "animate" : ""}`}
                >
                  <BookOpen className="w-5 h-5 text-primary pulse-glow flex-shrink-0" />
                  <span className="font-medium">Expert Exchanges</span>
                </div>
                <div
                  className={`flex items-center gap-3 text-foreground hover:text-primary transition-colors duration-300 fade-in-right stagger-2 ${isVisible ? "animate" : ""}`}
                >
                  <Users className="w-5 h-5 text-primary pulse-glow flex-shrink-0" />
                  <span className="font-medium">Verified Network</span>
                </div>
              </div>
            </div>
          </CardContent>
        </div>

        <p
          className={`text-center text-sm text-muted-foreground mt-6 fade-in-up stagger-6 ${isVisible ? "animate" : ""}`}
        >
          By continuing, you agree to our Terms of Service and Privacy Policy
        </p>
      </div>
    </div>
  )
}
