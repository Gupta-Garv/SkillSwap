"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Search, MessageCircle, ArrowLeft, Star, MapPin, Plus, X } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useUser } from "@/hooks/use-user"
import { getAllUsersForExchange, searchUsers } from "@/lib/user-data"
import { useMessaging } from "@/hooks/use-messaging"
import type { User } from "@/lib/types"

export default function ExchangePage() {
  const { currentUser, updateUser } = useUser()
  const { sendMessage: sendMessageToUser } = useMessaging(currentUser?.id)
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [messageText, setMessageText] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isCreateListingOpen, setIsCreateListingOpen] = useState(false)
  const [isVisible, setIsVisible] = useState(false)
  const [expandedSkills, setExpandedSkills] = useState<{ [key: string]: { teach: boolean; learn: boolean } }>({})

  // Create listing form state
  const [newSkillToTeach, setNewSkillToTeach] = useState("")
  const [newSkillToLearn, setNewSkillToLearn] = useState("")
  const [tempSkillsToTeach, setTempSkillsToTeach] = useState<string[]>(currentUser?.skillsToTeach || [])
  const [tempSkillsToLearn, setTempSkillsToLearn] = useState<string[]>(currentUser?.skillsToLearn || [])

  useEffect(() => {
    setIsVisible(true)

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate")
          }
        })
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" },
    )

    const elements = document.querySelectorAll(".fade-in-up, .fade-in-left, .fade-in-right, .scale-in")
    elements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  // Get filtered users
  const allUsers = searchTerm
    ? searchUsers(searchTerm, currentUser?.id)
    : getAllUsersForExchange(currentUser?.id)?.filter((user) => {
        return user.skillsToTeach.length > 0 && user.skillsToLearn.length > 0
      }) || []

  const handleSendMessage = (user: User) => {
    setSelectedUser(user)
    setIsDialogOpen(true)
  }

  const sendMessage = () => {
    if (messageText.trim() && selectedUser) {
      sendMessageToUser(selectedUser.id, messageText.trim())
      setMessageText("")
      setIsDialogOpen(false)
      router.push("/dashboard")
    }
  }

  const addSkillToTeach = () => {
    if (newSkillToTeach.trim() && !tempSkillsToTeach.includes(newSkillToTeach.trim())) {
      setTempSkillsToTeach([...tempSkillsToTeach, newSkillToTeach.trim()])
      setNewSkillToTeach("")
    }
  }

  const addSkillToLearn = () => {
    if (newSkillToLearn.trim() && !tempSkillsToLearn.includes(newSkillToLearn.trim())) {
      setTempSkillsToLearn([...tempSkillsToLearn, newSkillToLearn.trim()])
      setNewSkillToLearn("")
    }
  }

  const removeSkillToTeach = (skill: string) => {
    setTempSkillsToTeach(tempSkillsToTeach.filter((s) => s !== skill))
  }

  const removeSkillToLearn = (skill: string) => {
    setTempSkillsToLearn(tempSkillsToLearn.filter((s) => s !== skill))
  }

  const saveUserListing = () => {
    if (currentUser && tempSkillsToTeach.length > 0 && tempSkillsToLearn.length > 0) {
      updateUser({
        skillsToTeach: tempSkillsToTeach,
        skillsToLearn: tempSkillsToLearn,
      })
      setIsCreateListingOpen(false)
    }
  }

  const openCreateListing = () => {
    setTempSkillsToTeach(currentUser?.skillsToTeach || [])
    setTempSkillsToLearn(currentUser?.skillsToLearn || [])
    setIsCreateListingOpen(true)
  }

  const toggleSkillExpansion = (userId: string, type: "teach" | "learn") => {
    setExpandedSkills((prev) => ({
      ...prev,
      [userId]: {
        ...prev[userId],
        [type]: !prev[userId]?.[type],
      },
    }))
  }

  const renderSkills = (skills: string[], userId: string, type: "teach" | "learn", maxVisible = 3) => {
    const isExpanded = expandedSkills[userId]?.[type]
    const visibleSkills = isExpanded ? skills : skills.slice(0, maxVisible)
    const hiddenCount = skills.length - maxVisible

    return (
      <div className="flex flex-wrap gap-2">
        {visibleSkills.map((skill, index) => (
          <Badge
            key={index}
            className={
              type === "teach"
                ? "bg-gradient-to-r from-primary/20 to-primary/10 text-white hover:from-primary/30 hover:to-primary/20 border-primary/20 text-xs font-medium transition-all duration-300"
                : "border-border text-muted-foreground hover:bg-secondary text-xs font-medium transition-all duration-300"
            }
            variant={type === "teach" ? "default" : "outline"}
          >
            {skill}
          </Badge>
        ))}
        {!isExpanded && hiddenCount > 0 && (
          <button
            onClick={() => toggleSkillExpansion(userId, type)}
            className="inline-flex items-center px-2 py-1 text-xs font-medium text-primary hover:text-primary/80 bg-primary/10 hover:bg-primary/20 rounded-md transition-all duration-300"
          >
            +{hiddenCount} more
          </button>
        )}
        {isExpanded && skills.length > maxVisible && (
          <button
            onClick={() => toggleSkillExpansion(userId, type)}
            className="inline-flex items-center px-2 py-1 text-xs font-medium text-muted-foreground hover:text-foreground bg-secondary hover:bg-secondary/80 rounded-md transition-all duration-300"
          >
            Show less
          </button>
        )}
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/10"></div>

      <header className="bg-gradient-to-r from-background/90 via-background/95 to-background/90 backdrop-blur-xl border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <Link
              href="/dashboard"
              className="flex items-center gap-3 text-foreground hover:text-primary transition-all duration-300 hover:scale-105"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Dashboard</span>
            </Link>
            <Link href="/" className="text-3xl font-bold text-foreground hover:text-primary transition-colors float">
              SkillSwap
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12 relative z-10">
        <div
          className={`text-center mb-12 transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 scale-in">
            <span className="bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent">
              Professional Network
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed fade-in-up stagger-1">
            Connect with verified professionals. Exchange expertise and accelerate your career growth through meaningful
            collaborations.
          </p>
        </div>

        <div className="gradient-card mb-12 text-center p-8 fade-in-up stagger-2 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10"></div>
          <div className="relative z-10">
            <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl mx-auto mb-4 pulse-glow">
              <Plus className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-3">Create Your Listing</h3>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Share your expertise and learning goals with the professional community
            </p>
            <Button
              onClick={openCreateListing}
              className="gradient-button font-semibold px-8 py-3 pulse-glow hover:scale-105 transition-all duration-300"
            >
              Update Your Profile
            </Button>
          </div>
        </div>

        <div className="gradient-card mb-8 fade-in-up stagger-3">
          <div className="p-6">
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
                <Input
                  placeholder="Search by name, skills, or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-12 bg-input border-border text-foreground placeholder:text-muted-foreground h-12 rounded-xl"
                />
              </div>
              <div className="flex items-center gap-4">
                <p className="text-muted-foreground font-medium">{allUsers.length} professionals found</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {allUsers.map((user, index) => (
            <div
              key={user.id}
              className={`gradient-card group fade-in-up stagger-${(index % 6) + 1} flex flex-col h-full`}
            >
              <CardHeader className="pt-6 pb-4 pr-6">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16 ring-2 ring-primary/20 pulse-glow">
                    <AvatarImage src={user.profilePicture || "/placeholder.svg"} alt={user.name} />
                    <AvatarFallback className="bg-secondary text-secondary-foreground text-lg font-semibold">
                      {user.name
                        ? user.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                        : "?"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-xl text-foreground group-hover:text-primary transition-colors truncate">
                      {user.name}
                    </CardTitle>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-2">
                      <MapPin className="w-4 h-4 flex-shrink-0" />
                      <span className="truncate">{user.location}</span>
                    </div>
                    <div className="flex items-center gap-3 mt-2 flex-wrap">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-primary fill-current" />
                        <span className="text-sm font-semibold text-foreground">{user.rating}</span>
                      </div>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-sm text-primary font-semibold">{user.points} pts</span>
                      {user.isOnline && (
                        <>
                          <span className="text-muted-foreground">•</span>
                          <div className="flex items-center gap-1">
                            <div className="w-2 h-2 bg-primary rounded-full pulse-glow"></div>
                            <span className="text-sm text-primary font-medium">Online</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="flex-1 flex flex-col space-y-6 pb-6 pr-6">
                {user.bio && <p className="text-muted-foreground leading-relaxed line-clamp-2">{user.bio}</p>}

                <div className="flex-1 space-y-6">
                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-3">Can Teach:</h4>
                    {renderSkills(user.skillsToTeach, user.id, "teach")}
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-3">Wants to Learn:</h4>
                    {renderSkills(user.skillsToLearn, user.id, "learn")}
                  </div>
                </div>

                <Button
                  onClick={() => handleSendMessage(user)}
                  className="w-full gradient-button font-semibold py-3 pulse-glow transition-all duration-300 hover:scale-105 mt-auto"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Connect
                </Button>
              </CardContent>
            </div>
          ))}
        </div>

        {allUsers.length === 0 && (
          <div className="gradient-card text-center p-12 scale-in">
            <div className="w-20 h-20 bg-gradient-to-br from-secondary/50 to-secondary/30 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Search className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">No professionals found</h3>
            <p className="text-muted-foreground text-lg">Try adjusting your search terms to find more professionals.</p>
          </div>
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md bg-gradient-to-br from-card to-card/80 backdrop-blur-xl border-border">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-foreground">
              {selectedUser && (
                <>
                  <Avatar className="h-12 w-12 pulse-glow">
                    <AvatarImage src={selectedUser.profilePicture || "/placeholder.svg"} alt={selectedUser.name} />
                    <AvatarFallback className="bg-secondary text-secondary-foreground">
                      {selectedUser.name
                        ? selectedUser.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                        : "?"}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-bold text-lg">Connect with {selectedUser.name}</p>
                    <p className="text-sm text-muted-foreground font-normal">{selectedUser.location}</p>
                  </div>
                </>
              )}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <div>
              <Label htmlFor="message" className="text-foreground font-medium">
                Your Message
              </Label>
              <Textarea
                id="message"
                placeholder="Hi! I'm interested in connecting and potentially exchanging skills. Would you like to discuss?"
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                className="mt-2 bg-input border-border text-foreground placeholder:text-muted-foreground resize-none"
                rows={4}
              />
            </div>

            <div className="flex gap-3 justify-end">
              <Button
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                className="border-border text-foreground hover:bg-secondary"
              >
                Cancel
              </Button>
              <Button onClick={sendMessage} disabled={!messageText.trim()} className="gradient-button pulse-glow">
                <MessageCircle className="w-4 h-4 mr-2" />
                Send Message
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isCreateListingOpen} onOpenChange={setIsCreateListingOpen}>
        <DialogContent className="sm:max-w-2xl bg-gradient-to-br from-card to-card/80 backdrop-blur-xl border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground text-2xl">Update Your Professional Profile</DialogTitle>
            <p className="text-muted-foreground">Update your skills to help other professionals find you</p>
          </DialogHeader>

          <div className="space-y-8">
            <div className="space-y-4">
              <Label className="text-lg font-semibold text-foreground">Skills I can teach</Label>
              <div className="flex gap-3">
                <Input
                  placeholder="e.g., Web Development, Data Analysis, Project Management"
                  value={newSkillToTeach}
                  onChange={(e) => setNewSkillToTeach(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkillToTeach())}
                  className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                />
                <Button type="button" onClick={addSkillToTeach} className="gradient-button px-4">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {tempSkillsToTeach.map((skill) => (
                  <Badge
                    key={skill}
                    className="bg-gradient-to-r from-primary/20 to-primary/10 text-white hover:from-primary/30 hover:to-primary/20 border-primary/20 px-3 py-1 transition-all duration-300"
                  >
                    {skill}
                    <button onClick={() => removeSkillToTeach(skill)} className="ml-2 hover:text-primary/70">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label className="text-lg font-semibold text-foreground">Skills I want to learn</Label>
              <div className="flex gap-3">
                <Input
                  placeholder="e.g., Machine Learning, Design Thinking, Leadership"
                  value={newSkillToLearn}
                  onChange={(e) => setNewSkillToLearn(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkillToLearn())}
                  className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                />
                <Button
                  type="button"
                  onClick={addSkillToLearn}
                  className="bg-secondary hover:bg-secondary/80 text-secondary-foreground px-4"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {tempSkillsToLearn.map((skill) => (
                  <Badge
                    key={skill}
                    variant="outline"
                    className="border-border text-muted-foreground hover:bg-secondary px-3 py-1 transition-all duration-300"
                  >
                    {skill}
                    <button onClick={() => removeSkillToLearn(skill)} className="ml-2 hover:text-muted-foreground/70">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="flex gap-3 justify-end pt-4">
              <Button
                variant="outline"
                onClick={() => setIsCreateListingOpen(false)}
                className="border-border text-foreground hover:bg-secondary"
              >
                Cancel
              </Button>
              <Button
                onClick={saveUserListing}
                disabled={tempSkillsToTeach.length === 0 || tempSkillsToLearn.length === 0}
                className="gradient-button pulse-glow"
              >
                Update Profile
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
