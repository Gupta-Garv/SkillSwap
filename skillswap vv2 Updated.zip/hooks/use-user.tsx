"use client"

import { useState, useEffect, createContext, useContext, type ReactNode } from "react"
import type { User, UserStats } from "@/lib/types"
import { getUnreadMessageCount } from "@/lib/messaging"
import { safeSupabaseAuth } from "@/lib/supabase/client"
import type { User as SupabaseUser } from "@supabase/supabase-js"

interface UserContextType {
  currentUser: User | null
  userStats: UserStats
  updateUser: (userData: Partial<User>) => void
  isLoading: boolean
  refreshUser: () => void
  supabaseUser: SupabaseUser | null
}

const UserContext = createContext<UserContextType | undefined>(undefined)

export function UserProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isHydrated, setIsHydrated] = useState(false)
  const [supabaseUser, setSupabaseUser] = useState<SupabaseUser | null>(null)

  const loadUserData = async () => {
    try {
      const authData = localStorage.getItem("authData")
      if (!authData) {
        setCurrentUser(null)
        return
      }

      const parsedAuthData = JSON.parse(authData)
      const userData = localStorage.getItem("userData")
      const parsedUserData = userData ? JSON.parse(userData) : {}

      const user: User = {
        id: parsedAuthData.id || "current-user",
        name: parsedAuthData.name || "Current User",
        email: parsedAuthData.email || "user@example.com",
        bio: parsedUserData.bio || "",
        profilePicture: parsedUserData.profilePicture || null,
        skillsToTeach: parsedUserData.skillsToTeach || [],
        skillsToLearn: parsedUserData.skillsToLearn || [],
        location: parsedUserData.location || "Your Location",
        rating: 5.0,
        totalExchanges: parsedUserData.totalExchanges || 0,
        joinedDate: new Date().toISOString().split("T")[0],
        points: (parsedUserData.skillsToTeach?.length || 0) * 500,
        skillsTaught: parsedUserData.skillsToTeach?.length || 0,
        skillsLearned: parsedUserData.skillsLearned || 0,
        isOnline: true,
        learningMode: parsedUserData.learningMode || "both",
      }

      setCurrentUser(user)
    } catch (error) {
      console.error("Error loading user data:", error)
      setCurrentUser(null)
    }
  }

  const refreshUser = () => {
    loadUserData()
  }

  useEffect(() => {
    setIsHydrated(true)

    const initializeAuth = async () => {
      try {
        // Try to get Supabase user first
        const {
          data: { user: authUser },
        } = await safeSupabaseAuth.getUser()
        setSupabaseUser(authUser)

        // Load user data from localStorage regardless of Supabase state
        await loadUserData()
      } catch (error) {
        console.error("Error initializing auth:", error)
        // Fallback to localStorage only
        await loadUserData()
      } finally {
        setIsLoading(false)
      }
    }

    initializeAuth()

    let subscription: any
    try {
      const {
        data: { subscription: authSubscription },
      } = safeSupabaseAuth.onAuthStateChange(async (event, session) => {
        setSupabaseUser(session?.user ?? null)

        if (event === "SIGNED_OUT") {
          setCurrentUser(null)
          localStorage.removeItem("authData")
          localStorage.removeItem("userData")
        } else if (session?.user) {
          await loadUserData()
        }
      })
      subscription = authSubscription
    } catch (error) {
      console.error("Error setting up auth state listener:", error)
    }

    return () => {
      if (subscription) {
        subscription.unsubscribe()
      }
    }
  }, [])

  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "authData" || e.key === "userData") {
        loadUserData()
      }
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  const updateUser = (userData: Partial<User>) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, ...userData }

      if (userData.skillsToTeach) {
        updatedUser.points = userData.skillsToTeach.length * 500
        updatedUser.skillsTaught = userData.skillsToTeach.length
      }

      setCurrentUser(updatedUser)

      try {
        const storageData = {
          bio: updatedUser.bio,
          profilePicture: updatedUser.profilePicture,
          skillsToTeach: updatedUser.skillsToTeach,
          skillsToLearn: updatedUser.skillsToLearn,
          location: updatedUser.location,
          learningMode: updatedUser.learningMode,
          points: updatedUser.points,
          skillsTaught: updatedUser.skillsTaught,
          skillsLearned: updatedUser.skillsLearned,
          totalExchanges: updatedUser.totalExchanges,
        }
        localStorage.setItem("userData", JSON.stringify(storageData))
      } catch (error) {
        console.error("Error saving user data:", error)
      }
    }
  }

  const userStats: UserStats = {
    points: currentUser?.points || 0,
    skillsTaught: currentUser?.skillsTaught || 0,
    skillsLearned: currentUser?.skillsLearned || 0,
    newMessages: currentUser ? getUnreadMessageCount(currentUser.id) : 0,
  }

  if (!isHydrated || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your profile...</p>
        </div>
      </div>
    )
  }

  return (
    <UserContext.Provider value={{ currentUser, userStats, updateUser, isLoading, refreshUser, supabaseUser }}>
      {children}
    </UserContext.Provider>
  )
}

export function useUser() {
  const context = useContext(UserContext)
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider")
  }
  return context
}
