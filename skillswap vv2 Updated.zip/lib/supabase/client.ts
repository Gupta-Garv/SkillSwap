import { createClient } from "@supabase/supabase-js"

let supabaseInstance: ReturnType<typeof createClient> | null = null

// Lazy-load Supabase client
function getSupabaseClient() {
  if (supabaseInstance) {
    return supabaseInstance
  }

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  if (!supabaseUrl || !supabaseAnonKey) {
    console.warn("Supabase environment variables not found. Authentication will not work.")
    return null
  }

  supabaseInstance = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
    },
  })

  return supabaseInstance
}

// Export the client getter
export const supabase = getSupabaseClient()

// Check if Supabase is configured
export const isSupabaseConfigured = !!supabase

export const safeSupabaseAuth = {
  async signInWithPassword(credentials: { email: string; password: string }) {
    const client = getSupabaseClient()
    if (!client) {
      return {
        data: null,
        error: { message: "Supabase not configured. Using fallback authentication." },
      }
    }
    return await client.auth.signInWithPassword(credentials)
  },

  async signUp(options: { email: string; password: string; options?: any }) {
    const client = getSupabaseClient()
    if (!client) {
      return {
        data: { user: { id: "fallback-user", email: options.email } },
        error: { message: "Supabase not configured. Using fallback authentication." },
      }
    }
    return await client.auth.signUp(options)
  },

  async getUser() {
    const client = getSupabaseClient()
    if (!client) {
      return {
        data: { user: null },
        error: null,
      }
    }
    return await client.auth.getUser()
  },

  async getSession() {
    const client = getSupabaseClient()
    if (!client) {
      return {
        data: { session: null },
        error: null,
      }
    }
    return await client.auth.getSession()
  },

  onAuthStateChange(callback: (event: string, session: any) => void) {
    const client = getSupabaseClient()
    if (!client) {
      // Return a mock subscription for fallback
      return {
        data: {
          subscription: {
            unsubscribe: () => {},
          },
        },
      }
    }
    return client.auth.onAuthStateChange(callback)
  },
}

// Legacy exports for compatibility
export function createSupabaseClient() {
  const client = getSupabaseClient()
  if (!client) {
    throw new Error("Supabase is not configured. Please check your environment variables.")
  }
  return client
}

export { getSupabaseClient }
