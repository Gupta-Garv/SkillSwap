import type { Message, Conversation } from "./types"

// Mock messages for demonstration
const mockMessages: Message[] = [
  {
    id: "msg-1",
    senderId: "user-1",
    receiverId: "current-user",
    content: "Hi! I'm interested in learning React. Can you help?",
    timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
    read: false,
  },
  {
    id: "msg-2",
    senderId: "current-user",
    receiverId: "user-1",
    content: "Of course! I'd be happy to help you get started with React.",
    timestamp: new Date(Date.now() - 28 * 60 * 1000).toISOString(), // 28 minutes ago
    read: true,
  },
  {
    id: "msg-3",
    senderId: "user-1",
    receiverId: "current-user",
    content: "Thanks for the React tutorial! It was really helpful.",
    timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(), // 2 minutes ago
    read: false,
  },
  {
    id: "msg-4",
    senderId: "user-2",
    receiverId: "current-user",
    content: "When can we schedule the photography session?",
    timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(), // 1 hour ago
    read: false,
  },
  {
    id: "msg-5",
    senderId: "current-user",
    receiverId: "user-2",
    content: "How about this weekend? I'm free on Saturday afternoon.",
    timestamp: new Date(Date.now() - 55 * 60 * 1000).toISOString(), // 55 minutes ago
    read: true,
  },
  {
    id: "msg-6",
    senderId: "user-3",
    receiverId: "current-user",
    content: "The design looks great! Thanks for the feedback.",
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // Yesterday
    read: true,
  },
]

const adaptMockMessagesForUser = (currentUserId: string): Message[] => {
  return mockMessages.map((message) => ({
    ...message,
    senderId: message.senderId === "current-user" ? currentUserId : message.senderId,
    receiverId: message.receiverId === "current-user" ? currentUserId : message.receiverId,
  }))
}

// Get all messages from localStorage or use mock data
export const getMessages = (currentUserId = "current-user"): Message[] => {
  if (typeof window !== "undefined") {
    const stored = localStorage.getItem("messages")
    if (stored) {
      return JSON.parse(stored)
    }
  }
  return adaptMockMessagesForUser(currentUserId)
}

// Save messages to localStorage
export const saveMessages = (messages: Message[]): void => {
  if (typeof window !== "undefined") {
    localStorage.setItem("messages", JSON.stringify(messages))
  }
}

// Get conversations for current user
export const getConversations = (currentUserId = "current-user"): Conversation[] => {
  const messages = getMessages(currentUserId)
  const conversationMap = new Map<string, Conversation>()

  messages.forEach((message) => {
    const otherUserId = message.senderId === currentUserId ? message.receiverId : message.senderId

    if (!conversationMap.has(otherUserId)) {
      conversationMap.set(otherUserId, {
        id: `conv-${otherUserId}`,
        participants: [currentUserId, otherUserId],
        lastMessage: message,
        unreadCount: 0,
      })
    }

    const conversation = conversationMap.get(otherUserId)!

    // Update last message if this message is newer
    if (new Date(message.timestamp) > new Date(conversation.lastMessage.timestamp)) {
      conversation.lastMessage = message
    }

    // Count unread messages from other user
    if (message.senderId === otherUserId && !message.read) {
      conversation.unreadCount++
    }
  })

  return Array.from(conversationMap.values()).sort(
    (a, b) => new Date(b.lastMessage.timestamp).getTime() - new Date(a.lastMessage.timestamp).getTime(),
  )
}

// Get messages for a specific conversation
export const getConversationMessages = (currentUserId = "current-user", otherUserId: string): Message[] => {
  const messages = getMessages(currentUserId)
  return messages
    .filter(
      (message) =>
        (message.senderId === currentUserId && message.receiverId === otherUserId) ||
        (message.senderId === otherUserId && message.receiverId === currentUserId),
    )
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
}

// Send a new message
export const sendMessage = (senderId: string, receiverId: string, content: string): Message => {
  const messages = getMessages(senderId)
  const newMessage: Message = {
    id: `msg-${Date.now()}`,
    senderId,
    receiverId,
    content,
    timestamp: new Date().toISOString(),
    read: false,
  }

  messages.push(newMessage)
  saveMessages(messages)
  return newMessage
}

// Mark messages as read
export const markMessagesAsRead = (currentUserId = "current-user", otherUserId: string): void => {
  const messages = getMessages(currentUserId)
  const updatedMessages = messages.map((message) => {
    if (message.senderId === otherUserId && message.receiverId === currentUserId && !message.read) {
      return { ...message, read: true }
    }
    return message
  })
  saveMessages(updatedMessages)
}

// Get total unread message count
export const getUnreadMessageCount = (currentUserId = "current-user"): number => {
  const messages = getMessages(currentUserId)
  return messages.filter((message) => message.receiverId === currentUserId && !message.read).length
}

// Format timestamp for display
export const formatMessageTime = (timestamp: string): string => {
  const now = new Date()
  const messageTime = new Date(timestamp)
  const diffInMinutes = Math.floor((now.getTime() - messageTime.getTime()) / (1000 * 60))

  if (diffInMinutes < 1) return "Just now"
  if (diffInMinutes < 60) return `${diffInMinutes} min ago`
  if (diffInMinutes < 1440)
    return `${Math.floor(diffInMinutes / 60)} hour${Math.floor(diffInMinutes / 60) > 1 ? "s" : ""} ago`
  if (diffInMinutes < 10080)
    return `${Math.floor(diffInMinutes / 1440)} day${Math.floor(diffInMinutes / 1440) > 1 ? "s" : ""} ago`

  return messageTime.toLocaleDateString()
}

// Format message time for chat bubbles
export const formatChatTime = (timestamp: string): string => {
  const messageTime = new Date(timestamp)
  return messageTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
}
