export type PasswordStrength = "weak" | "decent" | "strong"

export interface PasswordValidation {
  strength: PasswordStrength
  score: number
  feedback: string[]
  isValid: boolean
}

export function validatePassword(password: string): PasswordValidation {
  const feedback: string[] = []
  let score = 0

  // Length check
  if (password.length >= 8) {
    score += 2
  } else {
    feedback.push("Password must be at least 8 characters long")
  }

  // Uppercase check
  if (/[A-Z]/.test(password)) {
    score += 1
  } else {
    feedback.push("Include at least one uppercase letter")
  }

  // Lowercase check
  if (/[a-z]/.test(password)) {
    score += 1
  } else {
    feedback.push("Include at least one lowercase letter")
  }

  // Number check
  if (/\d/.test(password)) {
    score += 1
  } else {
    feedback.push("Include at least one number")
  }

  // Special character check
  if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    score += 1
  } else {
    feedback.push("Include at least one special character")
  }

  // Length bonus
  if (password.length >= 12) {
    score += 1
  }

  // Determine strength
  let strength: PasswordStrength
  if (score <= 2) {
    strength = "weak"
  } else if (score <= 4) {
    strength = "decent"
  } else {
    strength = "strong"
  }

  // Only allow decent and strong passwords
  const isValid = strength === "decent" || strength === "strong"

  return {
    strength,
    score,
    feedback,
    isValid,
  }
}

export function getPasswordStrengthColor(strength: PasswordStrength): string {
  switch (strength) {
    case "weak":
      return "text-red-500"
    case "decent":
      return "text-yellow-500"
    case "strong":
      return "text-green-500"
    default:
      return "text-gray-500"
  }
}

export function getPasswordStrengthBg(strength: PasswordStrength): string {
  switch (strength) {
    case "weak":
      return "bg-red-500"
    case "decent":
      return "bg-yellow-500"
    case "strong":
      return "bg-green-500"
    default:
      return "bg-gray-500"
  }
}
